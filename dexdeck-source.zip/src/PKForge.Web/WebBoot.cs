using System.IO.Compression;
using System.Runtime.InteropServices.JavaScript;
using PKForge.Linux.Services;

namespace PKForge.Web;

/// <summary>
/// Gets the browser ready before the app starts: downloads the sprites into the in-memory file system, restores the
/// player's saves, Bank and settings from the browser's storage, then keeps that storage up to date.
/// </summary>
internal static partial class WebBoot
{
    private static readonly string[] Roots = ["/data", "/saves"];

    [JSImport("listKeys", "persist.js")]
    [return: JSMarshalAs<JSType.Promise<JSType.String>>]
    private static partial Task<string> ListKeysAsync();

    [JSImport("getValue", "persist.js")]
    [return: JSMarshalAs<JSType.Promise<JSType.String>>]
    private static partial Task<string?> GetValueAsync(string key);

    [JSImport("putValue", "persist.js")]
    [return: JSMarshalAs<JSType.Promise<JSType.Void>>]
    private static partial Task PutValueAsync(string key, string base64);

    [JSImport("removeValue", "persist.js")]
    [return: JSMarshalAs<JSType.Promise<JSType.Void>>]
    private static partial Task RemoveValueAsync(string key);

    [JSImport("setLoading", "persist.js")]
    private static partial void SetLoading(string text);

    [JSImport("keepStorage", "persist.js")]
    private static partial void KeepStorage();

    public static async Task PrepareAsync(string[] args)
    {
        try
        {
            SetLoading("Downloading sprites…");
            await LoadAssetsAsync(args.Length > 0 ? args[0] : "./");
            SetLoading("Restoring your Bank and saves…");
            await RestoreAsync();
            KeepStorage();
        }
        catch (Exception error)
        {
            SetLoading("Start-up problem: " + error.Message);
            AppPaths.LogCrash("web boot: " + error);
        }
        StartSync();
        SetLoading("");
    }

    private static async Task LoadAssetsAsync(string pageUrl)
    {
        using var http = new HttpClient { BaseAddress = new Uri(pageUrl) };
        var bytes = await http.GetByteArrayAsync("assets.zip");
        using var archive = new ZipArchive(new MemoryStream(bytes));
        archive.ExtractToDirectory(AppContext.BaseDirectory, overwriteFiles: true);
    }

    private static async Task RestoreAsync()
    {
        var keys = System.Text.Json.JsonSerializer.Deserialize<string[]>(await ListKeysAsync()) ?? [];
        foreach (var key in keys)
        {
            if (await GetValueAsync(key) is not { } base64) continue;
            var directory = System.IO.Path.GetDirectoryName(key);
            if (!string.IsNullOrEmpty(directory)) Directory.CreateDirectory(directory);
            File.WriteAllBytes(key, Convert.FromBase64String(base64));
        }
    }

    // ───────────── keeping the browser's storage in step with the in-memory folders ─────────────

    private static readonly Dictionary<string, (long Length, long Ticks)> Known = [];
    private static bool _syncing;

    private static void StartSync()
    {
        foreach (var file in EnumerateFiles()) Known[file] = Stamp(file);
        var timer = new Avalonia.Threading.DispatcherTimer { Interval = TimeSpan.FromSeconds(2) };
        timer.Tick += async (_, _) => await SyncAsync();
        timer.Start();
    }

    private static IEnumerable<string> EnumerateFiles()
    {
        foreach (var root in Roots)
        {
            if (!Directory.Exists(root)) continue;
            foreach (var file in Directory.EnumerateFiles(root, "*", SearchOption.AllDirectories))
                if (!file.EndsWith(".pkforge-tmp", StringComparison.Ordinal)) yield return file;
        }
    }

    private static (long, long) Stamp(string file)
    {
        var info = new FileInfo(file);
        return (info.Length, info.LastWriteTimeUtc.Ticks);
    }

    private static async Task SyncAsync()
    {
        if (_syncing) return;
        _syncing = true;
        try
        {
            var present = new HashSet<string>();
            foreach (var file in EnumerateFiles())
            {
                present.Add(file);
                var stamp = Stamp(file);
                if (Known.TryGetValue(file, out var old) && old == stamp) continue;
                await PutValueAsync(file, Convert.ToBase64String(File.ReadAllBytes(file)));
                Known[file] = stamp;
            }
            foreach (var gone in Known.Keys.Where(k => !present.Contains(k)).ToList())
            {
                await RemoveValueAsync(gone);
                Known.Remove(gone);
            }
        }
        catch (Exception error)
        {
            AppPaths.LogCrash("web sync: " + error);
        }
        finally
        {
            _syncing = false;
        }
    }
}
