using Avalonia;
using Avalonia.Browser;
using PKForge.Web;

internal sealed partial class Program
{
    private static async Task Main(string[] args)
    {
        await WebBoot.PrepareAsync(args);
        await BuildAvaloniaApp().WithInterFont().StartBrowserAppAsync("out");
    }

    public static AppBuilder BuildAvaloniaApp() => AppBuilder.Configure<PKForge.Web.App>();
}
