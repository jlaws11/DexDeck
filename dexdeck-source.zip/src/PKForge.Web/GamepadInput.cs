namespace PKForge.Linux;

internal enum PadButton { Up, Down, Left, Right, A, B, X, Y, L1, R1, Start, Select }

/// <summary>Browser stand-in for the controller reader: keyboard, mouse and touch drive the web version for now.</summary>
internal sealed class GamepadInput
{
#pragma warning disable CS0067
    public event Action<PadButton>? Pressed;
#pragma warning restore CS0067

    public static volatile string[] Devices = ["Browser: keyboard, mouse and touch"];
    public static IReadOnlyList<string> Trace => [];
    public static void Note(string text) { }
    public void Start() { }
    public void Stop() { }
}
