import { dotnet } from './_framework/dotnet.js'
import * as persist from './persist.js'

const runtime = await dotnet
    .withDiagnosticTracing(false)
    .withApplicationArgumentsFromQuery()
    .create();

runtime.setModuleImports('persist.js', persist);

const config = runtime.getConfig();
await runtime.runMain(config.mainAssemblyName, [new URL('./', globalThis.location.href).href]);
