namespace PKForge.Linux.Services;

public static class AppPaths
{
    public static string Home => OperatingSystem.IsBrowser() ? "/" : Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);

    /// <summary>Settings and crash notes live here (~/.local/share/PKForge).</summary>
    public static string DataDir
    {
        get
        {
            // In a browser there is no real disk: this is an in-memory folder that the web build copies into the browser's storage.
            if (OperatingSystem.IsBrowser())
            {
                Directory.CreateDirectory("/data");
                return "/data";
            }
            var root = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            var dir = Path.Combine(root, "DexDeck");
            var earlier = Path.Combine(root, "PKForge");
            // The app used to keep its data in "PKForge". Copy it across once so the Bank and restore points follow the new name.
            if (!Directory.Exists(dir) && Directory.Exists(earlier))
            {
                try { CopyAll(earlier, dir); }
                catch (Exception) { /* a half copy is replaced by a fresh start below */ }
            }
            Directory.CreateDirectory(dir);
            return dir;
        }
    }

    private static void CopyAll(string from, string to)
    {
        Directory.CreateDirectory(to);
        foreach (var file in Directory.GetFiles(from)) File.Copy(file, Path.Combine(to, Path.GetFileName(file)), overwrite: true);
        foreach (var sub in Directory.GetDirectories(from)) CopyAll(sub, Path.Combine(to, Path.GetFileName(sub)));
    }

    /// <summary>Reads a whole file even while an emulator has it open (Windows refuses a plain read then).</summary>
    public static byte[] ReadShared(string path)
    {
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
        using var memory = new MemoryStream();
        stream.CopyTo(memory);
        return memory.ToArray();
    }

    /// <summary>Where restore points are kept, for messages shown to the player.</summary>
    public static string BackupsHint => Path.Combine(DataDir, "backups");

    public static void LogCrash(string text)
    {
        try { File.AppendAllText(Path.Combine(DataDir, "crash.log"), $"[{DateTime.Now:O}] {text}\n\n"); }
        catch (Exception) { /* nowhere left to report to */ }
    }
}
