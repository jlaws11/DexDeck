using System.IO.Compression;
using Avalonia.Controls;
using Avalonia.Platform.Storage;

namespace PKForge.Linux.Services;

/// <summary>Browser helpers: where uploaded files live, and handing a file back to the player as a download.</summary>
public static class WebFiles
{
    /// <summary>Uploaded saves land here; Settings watches it like any other folder.</summary>
    public const string SavesDir = "/saves";

    /// <summary>Lets the player pick files and copies them into an in-browser folder. Returns the new paths.</summary>
    public static async Task<List<string>> UploadAsync(TopLevel? top, string folder, string title)
    {
        var result = new List<string>();
        if (top is null) return result;
        var picked = await top.StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions { Title = title, AllowMultiple = true });
        Directory.CreateDirectory(folder);
        foreach (var file in picked)
        {
            await using var stream = await file.OpenReadAsync();
            using var memory = new MemoryStream();
            await stream.CopyToAsync(memory);
            var name = System.IO.Path.GetFileName(file.Name);
            var path = System.IO.Path.Combine(folder, name);
            File.WriteAllBytes(path, memory.ToArray());
            result.Add(path);
        }
        return result;
    }

    /// <summary>Offers bytes as a download (a save-file dialog; in a browser this is a normal download).</summary>
    public static async Task<bool> SaveBytesAsync(TopLevel? top, string suggestedName, byte[] data)
    {
        if (top is null) return false;
        var target = await top.StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions { SuggestedFileName = suggestedName });
        if (target is null) return false;
        await using var stream = await target.OpenWriteAsync();
        await stream.WriteAsync(data);
        return true;
    }

    /// <summary>Zips every file under a folder and offers the zip as a download.</summary>
    public static Task<bool> SaveFolderAsZipAsync(TopLevel? top, string folder, string zipName)
    {
        using var memory = new MemoryStream();
        using (var zip = new ZipArchive(memory, ZipArchiveMode.Create, leaveOpen: true))
            foreach (var file in Directory.GetFiles(folder, "*", SearchOption.AllDirectories))
            {
                var entry = zip.CreateEntry(System.IO.Path.GetRelativePath(folder, file).Replace('\\', '/'));
                using var output = entry.Open();
                output.Write(File.ReadAllBytes(file));
            }
        return SaveBytesAsync(top, zipName, memory.ToArray());
    }
}
