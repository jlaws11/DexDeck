using System.Diagnostics;
using System.Text;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Layout;
using Avalonia.Platform.Storage;
using PKForge.Domain;
using PKForge.Engine;

namespace PKForge.Web;

/// <summary>
/// Feasibility test: can the PKForge engine run inside a browser? Pick a save file, open it with the engine,
/// list what is inside, then try the legality check and "Make it legal" on the first Pokémon.
/// </summary>
public sealed class TestView : UserControl
{
    private readonly TextBox _log = new() { IsReadOnly = true, AcceptsReturn = true, TextWrapping = Avalonia.Media.TextWrapping.Wrap, MinHeight = 300 };
    private readonly Button _legal = new() { Content = "Test: check + make first Pokémon legal", IsEnabled = false };
    private ISaveEngineSession? _session;
    private int _box, _slot;

    public TestView()
    {
        var pick = new Button { Content = "Choose a save file…" };
        pick.Click += async (_, _) => await PickAsync();
        _legal.Click += (_, _) => RunLegal();
        Content = new ScrollViewer
        {
            Content = new StackPanel
            {
                Margin = new Thickness(24), Spacing = 14, MaxWidth = 900,
                Children =
                {
                    new TextBlock { Text = "PKF-SOS Web: engine test", FontSize = 28, FontWeight = Avalonia.Media.FontWeight.Bold },
                    new TextBlock { Text = "Everything runs inside your browser. Your save never leaves this device.", Opacity = 0.7, TextWrapping = Avalonia.Media.TextWrapping.Wrap },
                    pick, _legal, _log,
                },
            },
        };
        Log("Ready. Engine runtime: " + Environment.Version + ", OS: " + RuntimeInformationText());
    }

    private static string RuntimeInformationText() => System.Runtime.InteropServices.RuntimeInformation.OSDescription;

    private void Log(string text) => _log.Text += text + "\n";

    private async Task PickAsync()
    {
        try
        {
            var top = TopLevel.GetTopLevel(this)!;
            var files = await top.StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions { Title = "Choose a save", AllowMultiple = false });
            if (files.Count == 0) return;
            await using var stream = await files[0].OpenReadAsync();
            using var memory = new MemoryStream();
            await stream.CopyToAsync(memory);
            var bytes = memory.ToArray();
            Log($"Read {files[0].Name}: {bytes.Length:N0} bytes");

            var engine = new SaveEngine();
            var watch = Stopwatch.StartNew();
            var description = engine.TryDescribe(bytes, files[0].Name);
            Log(description is null ? "The engine does not recognise this as a save." : $"Recognised: {description}");
            if (description is null) return;

            _session = engine.OpenSession(bytes, files[0].Name);
            Log($"Opened in {watch.ElapsedMilliseconds} ms: {_session.Snapshot.Format}, generation {_session.Snapshot.Generation}");
            var data = new GameDataService();
            var filled = _session.Snapshot.Slots.Where(s => s.Species is > 0).ToList();
            Log($"{filled.Count} Pokémon found. First few:");
            foreach (var s in filled.Take(8))
                Log($"  box {s.Box} slot {s.Slot}: {(s.Species is { } sp && sp < data.SpeciesNames.Count ? data.SpeciesNames[sp] : "?")}  legal={s.IsLegal}");
            if (filled.Count > 0)
            {
                _box = filled[0].Box;
                _slot = filled[0].Slot;
                _legal.IsEnabled = true;
            }
        }
        catch (Exception error)
        {
            Log("ERROR: " + error);
        }
    }

    private void RunLegal()
    {
        try
        {
            var watch = Stopwatch.StartNew();
            var report = new LegalityService().Analyze(_session!, _box, _slot);
            Log($"Legality check ({watch.ElapsedMilliseconds} ms): valid={report.Valid}");
            foreach (var line in report.Lines.Take(5)) Log("  " + line);
            watch.Restart();
            var result = new LegalizerService().LegalizeSlot(_session!, _box, _slot);
            Log($"Make it legal ({watch.ElapsedMilliseconds} ms): success={result.Success}: {result.Message}");
        }
        catch (Exception error)
        {
            Log("ERROR: " + error);
        }
    }
}
