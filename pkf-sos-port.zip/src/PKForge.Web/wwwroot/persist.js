// Keeps the player's files in the browser (IndexedDB) so the Bank, restore points and uploaded saves survive a reload.
const DB = 'pkfsos', STORE = 'files';

function open() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB, 1);
    request.onupgradeneeded = () => request.result.createObjectStore(STORE);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function run(mode, action) {
  return open().then(db => new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE, mode);
    const request = action(transaction.objectStore(STORE));
    transaction.oncomplete = () => resolve(request ? request.result : undefined);
    transaction.onerror = () => reject(transaction.error);
  }));
}

export const listKeys = () => run('readonly', s => s.getAllKeys()).then(keys => JSON.stringify(keys));
export const getValue = key => run('readonly', s => s.get(key)).then(v => (v === undefined ? null : v));
export const putValue = (key, value) => run('readwrite', s => s.put(value, key)).then(() => {});
export const removeValue = key => run('readwrite', s => s.delete(key)).then(() => {});
export const keepStorage = () => { try { navigator.storage?.persist?.(); } catch (e) { /* best effort */ } };
export const setLoading = text => {
  const element = document.getElementById('loading');
  if (!element) return;
  if (!text) element.remove(); else element.textContent = text;
};
