import { dotnet } from './_framework/dotnet.js'

const dotnetRuntime = await dotnet
    .withDiagnosticTracing(false)
    .withApplicationArgumentsFromQuery()
    .create();

const config = dotnetRuntime.getConfig();
document.getElementById('loading')?.remove();
await dotnetRuntime.runMain(config.mainAssemblyName, [globalThis.location.href]);
