using Avalonia;
using Avalonia.Controls;
using PKForge.Linux.Services;

namespace PKForge.Linux;

/// <summary>The extra home-screen pieces that only make sense in a browser: uploading saves and downloading them again.</summary>
public sealed partial class MainWindow
{
    private void AddWebButtons(WrapPanel tools)
    {
        if (!OperatingSystem.IsBrowser()) return;
        tools.Children.Insert(0, Ui.Btn("Upload saves", () => _ = UploadSavesAsync(), primary: true));
        tools.Children.Add(Ui.Btn("Download saves", ShowDownloads));
    }

    private async Task UploadSavesAsync()
    {
        try
        {
            var added = await WebFiles.UploadAsync(Top, WebFiles.SavesDir, "Choose your save files");
            if (added.Count == 0) return;
            var folder = _settings.Folders.FirstOrDefault(f => f.Path == WebFiles.SavesDir);
            if (folder is null)
            {
                folder = new WatchedFolder { Path = WebFiles.SavesDir, Kind = -1 };
                _settings.Folders.Add(folder);
                SettingsStore.Save(_settings);
            }
            SetStatus($"Added {added.Count} file(s). Looking for saves…");
            await ScanAsync(folder);
            ShowHome();
        }
        catch (Exception error)
        {
            SetStatus("Could not add those files: " + error.Message);
        }
    }

    private void ShowDownloads()
    {
        _back = ShowHome;
        _keys = null;
        var list = new StackPanel { Spacing = 10, Margin = new Thickness(32, 24) };
        var header = new StackPanel { Orientation = Avalonia.Layout.Orientation.Horizontal, Spacing = 18 };
        header.Children.Add(Ui.Btn("‹ Home", ShowHome));
        header.Children.Add(Ui.Text("Download saves", 36, true));
        list.Children.Add(header);
        list.Children.Add(Ui.Text("PKF-SOS Web edits the copy that lives in this browser. After you save changes, download the save here and put it back where your emulator or game keeps it.", 18, false, Ui.Dim));
        var any = false;
        foreach (var save in Shelf.All)
        {
            any = true;
            var chosen = save;
            var row = Ui.Btn($"Download   {save.GameLabel}   ·   {System.IO.Path.GetFileName(save.DocumentId)}", () => _ = DownloadSaveAsync(chosen));
            row.HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Stretch;
            row.HorizontalContentAlignment = Avalonia.Layout.HorizontalAlignment.Left;
            list.Children.Add(row);
        }
        if (!any) list.Children.Add(Ui.Text("No saves have been uploaded yet.", 18, false, Ui.Warn));
        _host.Content = new ScrollViewer { Content = list };
    }

    private async Task DownloadSaveAsync(DetectedSave save)
    {
        try
        {
            await WebFiles.SaveBytesAsync(Top, System.IO.Path.GetFileName(save.DocumentId), AppPaths.ReadShared(save.DocumentId));
        }
        catch (Exception error)
        {
            SetStatus("Could not download: " + error.Message);
        }
    }
}
