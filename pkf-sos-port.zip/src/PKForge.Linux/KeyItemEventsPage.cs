using Avalonia;
using Avalonia.Controls;
using Avalonia.Layout;
using PKForge.Domain;
using PKForge.Engine;
using PKForge.Linux.Services;

namespace PKForge.Linux;

/// <summary>
/// Key-item events: the tickets, passes and keys that open special legendary events (Eon Ticket, Aurora Ticket,
/// Member Card, Liberty Pass and so on). Each is switched on by writing the item plus the exact flags the real
/// distribution writes. Changes stay in memory until Save, which makes a restore point first.
/// </summary>
public sealed class KeyItemEventsPage : IScreen
{
    private readonly ContentControl _host;
    private readonly Action _close;
    private Workbench? _bench;
    private bool _dirty;
    private bool _busy;
    private string _note = "";

    public KeyItemEventsPage(ContentControl host, Action close)
    {
        _host = host;
        _close = close;
    }

    public IReadOnlyList<(string Button, string Label)> PadHints => _bench is null ? [] : [("X", "Save")];

    public bool OnKey(Avalonia.Input.Key key)
    {
        if (key == Avalonia.Input.Key.X && _bench is not null && _dirty && !_busy) { _ = SaveAsync(); return true; }
        return false;
    }

    public void Escape()
    {
        if (_busy) return;
        if (_bench is null) { _close(); return; }
        _bench = null;
        _dirty = false;
        _note = "";
        Start();
    }

    public void Start()
    {
        _host.Content = Workbench.Frame("Key-Item Events", Escape,
            Workbench.SavePicker("Which save do you want to set up key-item events in? (Gen 2 to Gen 6 games.)",
                s => s.Generation is >= 2 and <= 6, "No supported saves found yet. Add a folder in Settings first.", Open), "‹ Home");
    }

    private async void Open(DetectedSave save)
    {
        _host.Content = Workbench.Frame("Key-Item Events", Escape, Ui.Text("Opening the save…", 22));
        try
        {
            _bench = await Workbench.OpenAsync(save);
            _dirty = false;
            _note = _bench.Refusal ?? "";
            Render();
        }
        catch (Exception error)
        {
            _bench = null;
            _host.Content = Workbench.Frame("Key-Item Events", Escape, Ui.Text("Couldn't open that save: " + error.Message, 20, false, Ui.Warn));
        }
    }

    private static string StateText(KeyItemEventState state) => state switch
    {
        KeyItemEventState.Enabled => "Ready: the event is switched on",
        KeyItemEventState.Partial => "Half set up: the game ignores it until it is fixed",
        KeyItemEventState.Used => "Already used",
        KeyItemEventState.Completed => "Completed",
        _ => "Not switched on",
    };

    private void Render()
    {
        var bench = _bench!;
        var session = bench.Session;
        var body = new StackPanel { Spacing = 10 };
        if (!KeyItemEventService.IsSupported(session))
        {
            body.Children.Add(Ui.Text("This game has no key-item events to set up.", 22, true));
        }
        else
        {
            body.Children.Add(Ui.Text(bench.Save.GameLabel.Replace("Pokémon ", ""), 24, true));
            if (_note.Length > 0) body.Children.Add(Ui.Text(_note, 17, false, Ui.Warn));
            foreach (var ev in KeyItemEventService.GetEvents(session))
            {
                var card = new StackPanel { Spacing = 4 };
                card.Children.Add(Ui.Text(ev.Title, 22, true));
                card.Children.Add(Ui.Text(ev.Destination, 17, false, Ui.Dim));
                var good = ev.State is KeyItemEventState.Enabled;
                card.Children.Add(Ui.Text(StateText(ev.State), 17, true, good ? Ui.Gold : ev.State == KeyItemEventState.Partial ? Ui.Warn : Ui.Accent));
                if (ev.Prerequisite is { } prerequisite) card.Children.Add(Ui.Text(prerequisite, 15, false, Ui.Warn));

                var id = ev.Id;
                var actions = new WrapPanel { Margin = new Thickness(0, 6, 0, 0) };
                var on = ev.State is KeyItemEventState.NotEnabled or KeyItemEventState.Partial;
                var off = ev.State is KeyItemEventState.Enabled or KeyItemEventState.Partial;
                if (on)
                {
                    var b = Ui.Btn(ev.State == KeyItemEventState.Partial ? "Fix it" : "Switch on", () => Change(() => KeyItemEventService.Enable(session, id)), primary: true);
                    b.IsEnabled = bench.Refusal is null;
                    b.Margin = new Thickness(0, 0, 10, 0);
                    actions.Children.Add(b);
                }
                if (off)
                {
                    var b = Ui.Btn("Switch off", () => Change(() => KeyItemEventService.Disable(session, id)));
                    b.IsEnabled = bench.Refusal is null;
                    actions.Children.Add(b);
                }
                if (actions.Children.Count > 0) card.Children.Add(actions);
                body.Children.Add(new Border { Background = Ui.Panel, CornerRadius = new CornerRadius(10), Padding = new Thickness(16), Child = card });
            }
            body.Children.Add(Ui.Text("Nothing is written to the save until you press Save. A restore point is made first.", 16, false, Ui.Dim));
        }

        var save = Ui.Btn(_dirty ? "Save changes" : "No changes yet", () => _ = SaveAsync(), primary: _dirty);
        save.IsEnabled = _dirty && !_busy;
        save.HorizontalAlignment = HorizontalAlignment.Left;
        DockPanel.SetDock(save, Dock.Bottom);
        save.Margin = new Thickness(0, 10, 0, 0);

        var root = new DockPanel();
        root.Children.Add(save);
        root.Children.Add(new ScrollViewer { Content = body });
        _host.Content = Workbench.Frame("Key-Item Events", Escape, root);
    }

    private void Change(Func<GenerationOutcome> action)
    {
        try
        {
            var result = action();
            _note = result.Message;
            if (result.Success) _dirty = true;
        }
        catch (Exception error)
        {
            _note = "That didn't work: " + error.Message;
        }
        Render();
    }

    private async Task SaveAsync()
    {
        if (_bench is null || _busy) return;
        _busy = true;
        try
        {
            _note = await _bench.CommitAsync("Key-item events changed in PKF-SOS");
            _dirty = false;
        }
        catch (Exception error)
        {
            _note = "Not saved: " + error.Message;
        }
        _busy = false;
        Render();
    }
}
