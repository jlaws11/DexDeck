namespace PKForge.Linux;

/// <summary>The app version shown on the home and Credits screens. Keep in step with the release name.</summary>
internal static class AppInfo
{
    public const string Version = "2.2.1";
}
