using Avalonia;
using Avalonia.Controls;
using Avalonia.Layout;
using Avalonia.Media;
using PKForge.Domain;
using PKForge.Engine;
using PKForge.Infrastructure;
using PKForge.Linux.Services;

namespace PKForge.Linux;

/// <summary>
/// Import / Export for the Bank. Import reads a PKSM bank (.bnk + .json names), a PKSM dumps .zip,
/// or loose PKHeX-style files (.pk1 … .pk9, .pb7 …), shows a preview, then adds everything in one
/// go (all or nothing). Export writes the Bank out as a folder of PKHeX files or as a PKSM bank.
/// Files are chosen with a small built-in browser so it works with a controller in Gaming Mode.
/// </summary>
public sealed class BankTransferPage : IScreen
{
    private readonly ContentControl _host;
    private readonly Action _close;
    private readonly Stack<Action> _backStack = new();

    private string _dir = "";
    private bool _busy;

    private static readonly BankBoxNames BoxNames = new(Path.Combine(AppPaths.DataDir, "bank"));

    public BankTransferPage(ContentControl host, Action close)
    {
        _host = host;
        _close = close;
    }

    public void Escape()
    {
        if (_busy) return;
        if (_backStack.Count > 0) { _backStack.Pop()(); return; }
        _close();
    }

    public void Start() => ShowMenu();

    // ───────────────────────── menu ─────────────────────────

    private void ShowMenu()
    {
        _backStack.Clear();
        var body = new StackPanel { Spacing = 16, MaxWidth = 760, HorizontalAlignment = HorizontalAlignment.Center };
        body.Children.Add(Ui.Text($"Your Bank holds {Svc.Bank.GetAll().Count} Pokémon.", 22, true));
        body.Children.Add(Ui.Text("Import brings Pokémon in from a PKSM bank or from PKHeX files. Export writes your Bank out so you can use it in PKSM or PKHeX.", 18, false, Ui.Dim));
        body.Children.Add(Ui.Btn("Import into the Bank…", () => BrowseForImport(), primary: true));
        body.Children.Add(Ui.Btn("Export the Bank as PKHeX files…", () => BrowseForExport(false)));
        body.Children.Add(Ui.Btn("Export the Bank as a PKSM bank…", () => BrowseForExport(true)));
        body.Children.Add(Ui.Text(PksmBankTransfer.SdCardHelp, 16, false, Ui.Dim));
        _host.Content = Workbench.Frame("Import / Export", _close, new ScrollViewer { Content = body }, "‹ Home");
    }

    // ───────────────────────── file browser ─────────────────────────

    private static string StartDir()
    {
        var home = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        return Directory.Exists(home) ? home : "/";
    }

    private IEnumerable<(string Label, string Path)> Shortcuts()
    {
        var home = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        yield return ("Home", home);
        foreach (var sub in new[] { "Downloads", "Documents", "Desktop" })
            if (Directory.Exists(System.IO.Path.Combine(home, sub))) yield return (sub, System.IO.Path.Combine(home, sub));
        foreach (var root in new[] { "/run/media", "/media", "/mnt" })
        {
            if (!Directory.Exists(root)) continue;
            string[] kids;
            try { kids = Directory.GetDirectories(root); } catch { continue; }
            foreach (var kid in kids)
            {
                string[] inner;
                try { inner = Directory.GetDirectories(kid); } catch { inner = []; }
                // /run/media/<user>/<card>: show the cards, not the user folder.
                if (root == "/run/media" && inner.Length > 0)
                    foreach (var card in inner) yield return ("SD / USB: " + System.IO.Path.GetFileName(card), card);
                else
                    yield return ("Drive: " + System.IO.Path.GetFileName(kid), kid);
            }
        }
        if (OperatingSystem.IsWindows())
            foreach (var drive in DriveInfo.GetDrives().Where(d => d.IsReady))
                yield return ("Drive " + drive.Name, drive.Name);
    }

    private static bool Wanted(string name)
    {
        var ext = System.IO.Path.GetExtension(name).ToLowerInvariant();
        return ext is ".bnk" or ".zip" or ".json" || PksmBankTransfer.IsLooseMonFileName(name);
    }

    /// <summary>The browser: folders and importable files; "pickFolder" mode only shows folders.</summary>
    private void Browse(string title, string prompt, bool foldersOnly, Action<string> onFolder, Action<string>? onFile, string folderLabel)
    {
        if (!Directory.Exists(_dir)) _dir = StartDir();

        var list = new StackPanel { Spacing = 6 };
        var parent = System.IO.Path.GetDirectoryName(_dir.TrimEnd(System.IO.Path.DirectorySeparatorChar));
        if (!string.IsNullOrEmpty(parent))
            list.Children.Add(Ui.Btn("⬆  Up one folder", () => { _dir = parent; Browse(title, prompt, foldersOnly, onFolder, onFile, folderLabel); }));

        try
        {
            foreach (var dir in Directory.GetDirectories(_dir).OrderBy(d => d, StringComparer.OrdinalIgnoreCase))
            {
                var name = System.IO.Path.GetFileName(dir);
                if (name.StartsWith('.')) continue;
                var captured = dir;
                var b = Ui.Btn("📁  " + name, () => { _dir = captured; Browse(title, prompt, foldersOnly, onFolder, onFile, folderLabel); });
                b.HorizontalAlignment = HorizontalAlignment.Stretch;
                b.HorizontalContentAlignment = HorizontalAlignment.Left;
                list.Children.Add(b);
            }
            if (!foldersOnly)
                foreach (var file in Directory.GetFiles(_dir).Where(f => Wanted(f)).OrderBy(f => f, StringComparer.OrdinalIgnoreCase))
                {
                    var captured = file;
                    var b = Ui.Btn("📄  " + System.IO.Path.GetFileName(file), () => onFile?.Invoke(captured), primary: true);
                    b.HorizontalAlignment = HorizontalAlignment.Stretch;
                    b.HorizontalContentAlignment = HorizontalAlignment.Left;
                    list.Children.Add(b);
                }
        }
        catch (Exception error)
        {
            list.Children.Add(Ui.Text("Can't open this folder: " + error.Message, 18, false, Ui.Warn));
        }

        var places = new WrapPanel();
        foreach (var (label, path) in Shortcuts())
        {
            var captured = path;
            var b = Ui.Btn(label, () => { _dir = captured; Browse(title, prompt, foldersOnly, onFolder, onFile, folderLabel); });
            b.MinHeight = 44; b.FontSize = 17; b.Margin = new Thickness(0, 0, 8, 8);
            places.Children.Add(b);
        }

        var use = Ui.Btn(folderLabel, () => onFolder(_dir), primary: true);
        use.HorizontalAlignment = HorizontalAlignment.Stretch;

        var top = new StackPanel { Spacing = 8, Margin = new Thickness(0, 0, 0, 10) };
        top.Children.Add(Ui.Text(prompt, 18, false, Ui.Dim));
        top.Children.Add(places);
        top.Children.Add(Ui.Text(_dir, 17, true, Ui.Accent));
        top.Children.Add(use);
        DockPanel.SetDock(top, Dock.Top);

        var root = new DockPanel();
        root.Children.Add(top);
        root.Children.Add(new ScrollViewer { Content = list });
        _host.Content = Workbench.Frame(title, Escape, root);
    }

    // ───────────────────────── import ─────────────────────────

    private void BrowseForImport()
    {
        _backStack.Push(ShowMenu);
        if (OperatingSystem.IsBrowser()) { _ = PickUploadsAsync(); return; }
        if (string.IsNullOrEmpty(_dir)) _dir = StartDir();
        Browse("Import", "Pick a PKSM bank (.bnk), a dumps .zip or a single Pokémon file, or open the folder holding your files and use the button below.",
            false, folder => _ = PlanImportAsync(Directory.EnumerateFiles(folder, "*", new EnumerationOptions { RecurseSubdirectories = true, IgnoreInaccessible = true }), folder),
            file => _ = PlanImportAsync([file], file), "Import everything in this folder (including sub-folders)");
    }

    /// <summary>In a browser there is no folder to browse: the player picks files and they are copied into memory first.</summary>
    private async Task PickUploadsAsync()
    {
        try
        {
            var folder = "/import/" + DateTime.Now.Ticks;
            var added = await WebFiles.UploadAsync(TopLevel.GetTopLevel(_host), folder, "Choose a PKSM bank (.bnk and .json), a dumps .zip, or Pokémon files");
            if (added.Count == 0) return;
            await PlanImportAsync(added, "uploaded files");
        }
        catch (Exception error)
        {
            ShowMessage("Import", "Couldn't read that: " + error.Message, ShowMenu);
        }
    }

    private async Task PlanImportAsync(IEnumerable<string> paths, string label)
    {
        _busy = true;
        _host.Content = Workbench.Frame("Import", Escape, Ui.Text("Reading files…", 22));
        try
        {
            var (plans, ignored, tooMany) = await Task.Run(() =>
            {
                var files = new List<(string, byte[])>();
                var many = false;
                foreach (var path in paths)
                {
                    if (!Wanted(path) && !path.EndsWith("bank.bin", StringComparison.OrdinalIgnoreCase)) continue;
                    if (files.Count >= 20000) { many = true; break; }
                    var info = new FileInfo(path);
                    if (info.Length > 256L * 1024 * 1024) continue;
                    files.Add((System.IO.Path.GetFileName(path), File.ReadAllBytes(path)));
                }
                var sources = PksmBankTransfer.Collect(files);
                var result = new List<PksmImportPlan>();
                foreach (var (name, bnk, json) in sources.Banks)
                {
                    try { result.Add(PksmBankTransfer.PlanBank(name, bnk, json ?? [], Decode)); }
                    catch (InvalidDataException error) { sources = sources with { Ignored = [.. sources.Ignored, error.Message] }; }
                }
                if (sources.LooseFiles.Count > 0)
                    result.Add(PksmBankTransfer.PlanLoose($"{sources.LooseFiles.Count} loose file(s)", sources.LooseFiles, Decode));
                return (result, sources.Ignored, many);
            });
            _busy = false;
            ShowPreview(plans, ignored, tooMany, label);
        }
        catch (Exception error)
        {
            _busy = false;
            ShowMessage("Import", "Couldn't read that: " + error.Message, ShowMenu);
        }
    }

    private void ShowPreview(List<PksmImportPlan> plans, IReadOnlyList<string> ignored, bool tooMany, string label)
    {
        var ready = plans.Sum(p => p.ReadyCount);
        var skipped = plans.Sum(p => p.SkippedCount);
        var body = new StackPanel { Spacing = 12, MaxWidth = 820, HorizontalAlignment = HorizontalAlignment.Center };

        if (plans.Count == 0)
        {
            body.Children.Add(Ui.Text("Nothing importable found.", 24, true));
            body.Children.Add(Ui.Text("PKF-SOS reads PKSM banks (.bnk, with the .json beside it), PKSM dump .zip files, and loose .pk1 – .pk9 / .pb7 files from PKHeX.", 18, false, Ui.Dim));
        }
        else
        {
            body.Children.Add(Ui.Text($"Found {ready} Pokémon ready to import", 26, true));
            foreach (var plan in plans)
            {
                var card = new StackPanel { Spacing = 4 };
                card.Children.Add(Ui.Text(plan.IsBank ? $"PKSM bank “{plan.Source}” · {plan.UsedBoxes} boxes" : plan.Source, 21, true));
                if (plan.CountsByGeneration.Count > 0)
                    card.Children.Add(Ui.Text(string.Join("   ", plan.CountsByGeneration.Select(c => $"{c.Label}: {c.Count}")), 18, false, Ui.Accent));
                if (plan.Truncated) card.Children.Add(Ui.Text("This bank file looks cut short; only the readable part will be imported.", 17, false, Ui.Warn));
                foreach (var (reason, count) in plan.SkipReasons)
                    card.Children.Add(Ui.Text($"Left out ({count}): {reason}", 17, false, Ui.Warn));
                body.Children.Add(new Border { Background = Ui.Panel, CornerRadius = new CornerRadius(10), Padding = new Thickness(16), Child = card });
            }
            body.Children.Add(Ui.Text("Exact copies of Pokémon already in your Bank are skipped, so importing the same thing twice is harmless. Everything is added in one go, or nothing is.", 17, false, Ui.Dim));
        }
        if (tooMany) body.Children.Add(Ui.Text("That folder holds a huge number of files; only the first 20,000 were read.", 17, false, Ui.Warn));
        if (ignored.Count > 0)
            body.Children.Add(Ui.Text($"Ignored {ignored.Count} other file(s) (e.g. {string.Join(", ", ignored.Take(3))}).", 16, false, Ui.Dim));

        var actions = new WrapPanel();
        var back = Ui.Btn("‹ Back", () => { _backStack.TryPop(out _); BrowseForImport(); });
        back.Margin = new Thickness(0, 0, 12, 0);
        actions.Children.Add(back);
        if (ready > 0)
        {
            var put = Ui.Btn(plans.Any(p => p.IsBank) ? "Import into new Bank boxes" : "Import into the Bank", () => ApplyImport(plans, PksmImportMode.NewBoxes), primary: true);
            put.Margin = new Thickness(0, 0, 12, 0);
            actions.Children.Add(put);
            if (plans.Any(p => p.IsBank))
                actions.Children.Add(Ui.Btn("Fill free slots instead", () => ApplyImport(plans, PksmImportMode.Merge)));
        }
        body.Children.Add(actions);
        _host.Content = Workbench.Frame("Import preview", Escape, new ScrollViewer { Content = body });
        _ = skipped;
    }

    private void ApplyImport(List<PksmImportPlan> plans, PksmImportMode mode)
    {
        try
        {
            var result = PksmBankTransfer.Apply(Svc.Bank, BoxNames, plans, mode);
            var text = result.Imported == 0
                ? $"Nothing new to add — all {result.Duplicates} were already in your Bank."
                : $"Imported {result.Imported} Pokémon" + (result.Duplicates > 0 ? $" ({result.Duplicates} duplicates skipped)." : ".") +
                  (mode == PksmImportMode.NewBoxes && result.BoxesUsed > 0 ? $" They're in Bank boxes {result.FirstNewBox + 1}–{result.FirstNewBox + result.BoxesUsed}." : "");
            ShowMessage("Import done", text, ShowMenu);
        }
        catch (Exception error)
        {
            ShowMessage("Import failed", "Nothing was changed. " + error.Message, ShowMenu);
        }
    }

    // ───────────────────────── export ─────────────────────────

    private void BrowseForExport(bool pksm)
    {
        _backStack.Push(ShowMenu);
        if (Svc.Bank.GetAll().Count == 0)
        {
            ShowMessage("Export", "Your Bank is empty, so there is nothing to export yet.", ShowMenu);
            return;
        }
        if (OperatingSystem.IsBrowser())
        {
            var staging = "/export/" + DateTime.Now.Ticks;
            Directory.CreateDirectory(staging);
            _ = ExportAsync(pksm, staging);
            return;
        }
        if (string.IsNullOrEmpty(_dir)) _dir = StartDir();
        Browse(pksm ? "Export as a PKSM bank" : "Export as PKHeX files",
            "Open the folder you want the export saved in (a USB stick or SD card works too), then use the button below.",
            true, folder => _ = ExportAsync(pksm, folder), null, "Export here");
    }

    private async Task ExportAsync(bool pksm, string folder)
    {
        _busy = true;
        _host.Content = Workbench.Frame("Export", Escape, Ui.Text("Exporting…", 22));
        try
        {
            var stamp = DateTime.Now.ToString("yyyy-MM-dd_HHmm");
            var entries = Svc.Bank.GetAll();
            if (pksm)
            {
                var name = PksmBankTransfer.SanitizeBankName("pkfsos-" + stamp);
                var result = await Task.Run(() => PksmBankTransfer.Export(Svc.Bank, entries, Encode, BoxNames.Get, PksmExportLayout.KeepPositions));
                await File.WriteAllBytesAsync(System.IO.Path.Combine(folder, name + ".bnk"), result.Bank);
                await File.WriteAllBytesAsync(System.IO.Path.Combine(folder, name + ".json"), result.BoxNames);
                _busy = false;
                var lines = $"Wrote {result.Written} Pokémon in {result.Boxes} boxes to:\n{System.IO.Path.Combine(folder, name)}.bnk and .json";
                if (result.Skipped.Count > 0)
                    lines += $"\n\n{result.Skipped.Count} left out because PKSM can't hold them (" +
                             string.Join("; ", result.Skipped.GroupBy(s => s.Reason).Take(3).Select(g => $"{g.Count()}× {g.Key}")) + ").";
                lines += "\n\n" + PksmBankTransfer.ReturnHelp.Replace("NAME", name);
                if (OperatingSystem.IsBrowser())
                {
                    if (await WebFiles.SaveFolderAsZipAsync(TopLevel.GetTopLevel(_host), folder, name + ".zip"))
                        lines = "Your bank was downloaded as " + name + ".zip. Unzip it to get the .bnk and .json files.\n\n" + lines;
                }
                ShowMessage("Export done", lines, ShowMenu);
            }
            else
            {
                var target = System.IO.Path.Combine(folder, "PKF-SOS-bank-" + stamp);
                Directory.CreateDirectory(target);
                var count = await BankArchive.ExportAsync(Svc.Bank, new LocalFolder(), target, entries);
                _busy = false;
                if (OperatingSystem.IsBrowser())
                {
                    await WebFiles.SaveFolderAsZipAsync(TopLevel.GetTopLevel(_host), target, "PKF-SOS-bank-" + stamp + ".zip");
                    ShowMessage("Export done", $"Downloaded {count} Pokémon files plus manifest.json as a zip. PKHeX can open the .pk files inside.", ShowMenu);
                    return;
                }
                ShowMessage("Export done", $"Wrote {count} Pokémon files plus manifest.json to:\n{target}\n\nPKHeX can open or drag-and-drop these .pk files directly.", ShowMenu);
            }
        }
        catch (Exception error)
        {
            _busy = false;
            ShowMessage("Export failed", error.Message, ShowMenu);
        }
    }

    // ───────────────────────── helpers ─────────────────────────

    private void ShowMessage(string title, string text, Action then)
    {
        _backStack.Clear();
        var body = new StackPanel { Spacing = 16, MaxWidth = 760, HorizontalAlignment = HorizontalAlignment.Center };
        body.Children.Add(Ui.Text(text, 20));
        var ok = Ui.Btn("OK", then, primary: true);
        ok.HorizontalAlignment = HorizontalAlignment.Left;
        body.Children.Add(ok);
        _host.Content = Workbench.Frame(title, then, new ScrollViewer { Content = body });
    }

    private static PksmDecoded Decode(PksmGeneration? generation, byte[] bytes, string source)
    {
        var number = generation is { } g ? PksmBankFile.GenerationNumber(g) : (int?)null;
        if (number == 0) return PksmDecoded.Skip($"unknown generation tag 0x{(uint)generation!.Value:X}");
        var result = PksmEntityConversion.Decode(number, generation == PksmGeneration.LetsGo, bytes, source);
        return new PksmDecoded(result.Bytes, result.Info, result.Reason);
    }

    private static PksmEncoded Encode(byte[] bankBytes, string? format)
    {
        var result = PksmEntityConversion.Encode(bankBytes, format);
        return result.Data is not null && PksmBankFile.FromGenerationNumber(result.Generation, result.LetsGo) is { } tag
            ? new PksmEncoded(tag, result.Data, null)
            : PksmEncoded.Skip(result.Reason ?? "PKSM has no slot for this format");
    }

    /// <summary>Plain-folder file access for BankArchive: the "tree id" is just the directory path.</summary>
    private sealed class LocalFolder : IFolderFileAccess
    {
        public ValueTask<IReadOnlyList<PickedDocument>> ListFilesAsync(string treeId, CancellationToken cancellationToken = default) =>
            new((IReadOnlyList<PickedDocument>)Directory.GetFiles(treeId).Select(f => new PickedDocument(f, System.IO.Path.GetFileName(f))).ToArray());

        public async ValueTask<ReadOnlyMemory<byte>> ReadFileAsync(string documentId, CancellationToken cancellationToken = default) =>
            await File.ReadAllBytesAsync(documentId, cancellationToken);

        public async ValueTask WriteFileAsync(string treeId, string fileName, ReadOnlyMemory<byte> bytes, CancellationToken cancellationToken = default) =>
            await File.WriteAllBytesAsync(System.IO.Path.Combine(treeId, fileName), bytes.ToArray(), cancellationToken);
    }
}
