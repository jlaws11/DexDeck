using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Media;
using PKForge.Domain;
using PKForge.Engine;
using PKForge.Linux.Services;

namespace PKForge.Linux;

/// <summary>
/// Who is in the party right now: sprite, level, HP and any status, with buttons to restore health and remove
/// status for one Pokémon or the whole party. Nothing is written until Save is pressed.
/// </summary>
public sealed class PartyPage : IScreen
{
    private readonly ContentControl _host;
    private readonly SpriteStore _sprites;
    private readonly DetectedSave _save;
    private readonly Action _close;
    private readonly Action<EditTarget, Action<bool>> _openEditor;

    private Workbench? _bench;
    private bool _dirty;
    private bool _confirmDiscard;
    private bool _busy;
    private string _note = "";
    private bool _noteIsError;

    public PartyPage(ContentControl host, SpriteStore sprites, DetectedSave save, Action<EditTarget, Action<bool>> openEditor, Action close)
    {
        _host = host;
        _sprites = sprites;
        _save = save;
        _close = close;
        _openEditor = openEditor;
    }

    public IReadOnlyList<(string Button, string Label)> PadHints => _bench is null ? [] : [("X", "Save")];

    public bool OnKey(Key key)
    {
        if (key == Key.X && _bench is not null && _dirty && !_busy && _bench.Refusal is null) { _ = SaveAsync(); return true; }
        return false;
    }

    public void Escape()
    {
        if (_busy) return;
        if (_bench is not null && _dirty && !_confirmDiscard)
        {
            _confirmDiscard = true;
            _note = "You have unsaved changes. Press Back again to throw them away, or tap Save.";
            _noteIsError = true;
            Render();
            return;
        }
        _close();
    }

    public void Start() => _ = OpenAsync();

    private async Task OpenAsync()
    {
        _host.Content = Workbench.Frame("Party", Escape, Ui.Text("Getting the party…", 22), "‹ Back");
        try
        {
            _bench = await Workbench.OpenAsync(_save);
            _dirty = false;
            _note = _bench.Refusal is null ? "" : "This save cannot be written, so you can look but not save: " + _bench.Refusal;
            _noteIsError = _bench.Refusal is not null;
            Render();
        }
        catch (Exception error)
        {
            _bench = null;
            _host.Content = Workbench.Frame("Party", _close, Ui.Text("Could not open that save: " + error.Message, 20, false, Ui.Warn), "‹ Back");
        }
    }

    private static string StatusName(int status)
    {
        if (status == 0) return "Healthy";
        var parts = new List<string>();
        if ((status & 7) != 0) parts.Add("Asleep");
        if ((status & 8) != 0) parts.Add("Poisoned");
        if ((status & 16) != 0) parts.Add("Burned");
        if ((status & 32) != 0) parts.Add("Frozen");
        if ((status & 64) != 0) parts.Add("Paralyzed");
        if ((status & 128) != 0) parts.Add("Badly poisoned");
        return parts.Count == 0 ? "Status " + status : string.Join(", ", parts);
    }

    private List<EntityDetail> Members()
    {
        var list = new List<EntityDetail>();
        for (var i = 0; i < 6; i++)
        {
            try
            {
                var d = _bench!.Session.ReadEntity(-1, i);
                if (!d.IsEmpty && d.Species > 0) list.Add(d);
            }
            catch (Exception) { }
        }
        return list;
    }

    private void Render()
    {
        var bench = _bench!;
        var members = Members();
        var canEdit = bench.Refusal is null && !_busy;

        var list = new StackPanel { Spacing = 8 };
        if (members.Count > 0)
            list.Children.Add(Ui.Text("Tap a Pokémon's picture to edit it.", 15, false, Ui.Dim));
        if (members.Count == 0)
            list.Children.Add(Ui.Text("There is nobody in this save's party.", 20, false, Ui.Dim));
        foreach (var d in members) list.Children.Add(Row(d, canEdit));

        var bar = new DockPanel { Margin = new Thickness(0, 10, 0, 0) };
        var save = Ui.Btn("Save to the game", () => _ = SaveAsync(), primary: true);
        save.IsEnabled = _dirty && canEdit;
        DockPanel.SetDock(save, Dock.Right);
        bar.Children.Add(save);
        var healAll = Ui.Btn("Restore whole party", () => Run(null, VitalsActions.Kind.HealAll, "Whole party healed."));
        var cureAll = Ui.Btn("Remove all status effects", () => Run(null, VitalsActions.Kind.CureStatus, "All status effects removed."));
        healAll.IsEnabled = cureAll.IsEnabled = canEdit && members.Count > 0;
        healAll.MinWidth = cureAll.MinWidth = 0;
        healAll.Margin = new Thickness(0, 0, 10, 0);
        var left = new StackPanel { Orientation = Orientation.Horizontal };
        left.Children.Add(healAll);
        left.Children.Add(cureAll);
        DockPanel.SetDock(left, Dock.Left);
        bar.Children.Add(left);
        bar.Children.Add(Ui.Text(_busy ? "Working…" : _note, 15, false, _noteIsError ? Ui.Warn : Ui.Gold));
        DockPanel.SetDock(bar, Dock.Bottom);

        var body = new DockPanel();
        body.Children.Add(bar);
        body.Children.Add(new ScrollViewer { Content = list, HorizontalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Disabled });
        _host.Content = Workbench.Frame($"Party · {bench.Save.GameLabel.Replace("Pokémon ", "")}", Escape, body, "‹ Back");
    }

    private Control Row(EntityDetail d, bool canEdit)
    {
        var slot = d.Slot;
        var row = new DockPanel { Margin = new Thickness(4, 2) };

        var buttons = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8, VerticalAlignment = VerticalAlignment.Center };
        var heal = Ui.Btn("Restore health", () => Run(slot, VitalsActions.Kind.HealAll, "Healed."));
        var cure = Ui.Btn("Remove status", () => Run(slot, VitalsActions.Kind.CureStatus, "Status removed."));
        foreach (var b in new[] { heal, cure }) { b.MinWidth = 0; b.MinHeight = 50; b.FontSize = 17; b.Padding = new Thickness(14, 4); b.IsEnabled = canEdit; }
        buttons.Children.Add(heal);
        buttons.Children.Add(cure);
        DockPanel.SetDock(buttons, Dock.Right);
        row.Children.Add(buttons);

        {
            var image = new Image { Stretch = Stretch.Uniform, Width = 100, Height = 100 };
            if (_sprites.GetFilled(d.Look) is { } sprite) image.Source = sprite;
            var pick = new Button
            {
                Content = image,
                Width = 88,
                Height = 88,
                Padding = new Thickness(0),
                Margin = new Thickness(0, 0, 12, 0),
                Background = Ui.Bg,
                BorderBrush = Ui.Edge,
                BorderThickness = new Thickness(2),
                CornerRadius = new CornerRadius(10),
                HorizontalContentAlignment = HorizontalAlignment.Center,
                VerticalContentAlignment = VerticalAlignment.Center,
                IsEnabled = !_busy,
            };
            pick.Click += (_, _) => _ = EditAsync(slot);
            DockPanel.SetDock(pick, Dock.Left);
            row.Children.Add(pick);
        }

        var max = d.Stats is { Count: 6 } s ? Math.Max(1, s[0]) : Math.Max(1, d.CurrentHp);
        var fraction = Math.Clamp(d.CurrentHp / (double)max, 0, 1);
        var info = new StackPanel { Spacing = 4, VerticalAlignment = VerticalAlignment.Center };
        var name = string.IsNullOrWhiteSpace(d.Nickname) ? d.SpeciesName : d.Nickname;
        info.Children.Add(Ui.Text($"{name}   Lv {d.Level}", 20, true));
        var track = new Border { Width = 260, Height = 14, CornerRadius = new CornerRadius(7), Background = Ui.Bg, HorizontalAlignment = HorizontalAlignment.Left };
        track.Child = new Border
        {
            Width = 260 * fraction,
            CornerRadius = new CornerRadius(7),
            HorizontalAlignment = HorizontalAlignment.Left,
            Background = new SolidColorBrush(Color.Parse(fraction > 0.5 ? "#4CC36B" : fraction > 0.2 ? "#E8B53A" : "#E5533D")),
        };
        info.Children.Add(track);
        var status = StatusName(d.StatusCondition);
        info.Children.Add(Ui.Text($"HP {d.CurrentHp} / {max}   ·   {status}", 16, false, d.StatusCondition == 0 ? Ui.Dim : Ui.Warn));
        row.Children.Add(info);

        return new Border { Background = Ui.Panel, CornerRadius = new CornerRadius(8), Padding = new Thickness(12, 8), Child = row };
    }

    private async Task EditAsync(int slot)
    {
        if (_bench is null || _busy) return;
        if (_dirty)
        {
            _note = "Save your changes first, then tap the picture to edit.";
            _noteIsError = true;
            Render();
            return;
        }
        try
        {
            var target = await EditTarget.ForSaveAsync(_save, -1, slot);
            _openEditor(target, _ => Start());
        }
        catch (Exception error)
        {
            _note = "Could not open the editor: " + error.Message;
            _noteIsError = true;
            Render();
        }
    }

    private void Run(int? slot, VitalsActions.Kind kind, string done)
    {
        if (_bench is null || _busy) return;
        var changed = 0;
        try
        {
            var targets = slot is { } one ? [one] : Members().Select(m => m.Slot).ToList();
            foreach (var s in targets)
                if (VitalsActions.Apply(_bench.Session, -1, s, kind)) changed++;
            if (changed > 0) { _dirty = true; _confirmDiscard = false; }
            _note = changed > 0 ? done : "Nothing needed changing.";
            _noteIsError = false;
        }
        catch (Exception error)
        {
            _note = "That did not work: " + error.Message;
            _noteIsError = true;
        }
        Render();
    }

    private async Task SaveAsync()
    {
        var bench = _bench;
        if (bench is null || _busy) return;
        _busy = true;
        Render();
        try
        {
            _note = await bench.CommitAsync("Healed the party in PKForge");
            _dirty = false;
            _confirmDiscard = false;
            _noteIsError = false;
        }
        catch (Exception error)
        {
            _note = "Could not save: " + error.Message;
            _noteIsError = true;
        }
        _busy = false;
        Render();
    }
}
