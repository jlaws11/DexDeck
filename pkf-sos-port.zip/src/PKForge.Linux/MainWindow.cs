using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Platform.Storage;
using Avalonia.VisualTree;
using PKForge.Domain;
using PKForge.Engine;
using PKForge.Linux.Services;

namespace PKForge.Linux;

/// <summary>
/// Stage 1 of the Linux port: point the app at a folder, see the saves in it, open one and browse its boxes.
/// Read-only: nothing here ever writes to a save file.
/// </summary>
public sealed class MainWindow : Window
{
    private static readonly (string Label, int Kind)[] KindChoices =
    [
        ("Auto-detect (recommended)", -1),
        ("RetroArch (GBA / GB / DS saves)", (int)EmulatorKind.RetroArch),
        ("Azahar / Citra (3DS)", (int)EmulatorKind.Azahar),
        ("melonDS (DS)", (int)EmulatorKind.MelonDS),
    ];

    private readonly ISaveEngine _engine = Svc.Engine;
    private readonly IGameDataService _data = Svc.Data;
    private readonly LinuxEmulatorScanner _scanner;
    private readonly SpriteStore _sprites = new();
    private readonly AppSettings _settings = LoadSettings();
    private Border _bar = null!;

    private static AppSettings LoadSettings()
    {
        var loaded = SettingsStore.Load();
        Ui.Apply(loaded.Theme);
        return loaded;
    }
    private readonly ContentControl _host = new();

    private CancellationTokenSource? _scanCts;
    private Action? _back;
    private readonly List<IScreen> _screens = [];
    private Func<Key, bool>? _keys;

    // controller support
    private readonly GamepadInput _pad = new();
    private readonly StackPanel _hintBar = new() { Orientation = Orientation.Horizontal, Spacing = 26 };
    private bool _padActive;
    private int _lastFocusIndex;
    private IScreen? _lastTop;
    private readonly System.Runtime.CompilerServices.ConditionalWeakTable<Button, FocusMemo> _focusMemo = new();
    private sealed record FocusMemo(IBrush? Border, Thickness Thickness);

    private List<DetectedSave> _lastSaves = [];
    private string _status = "";
    private TextBlock _statusBlock = new();
    private StackPanel _resultsPanel = new();
    private TextBox _pathBox = new();
    private ComboBox _kindBox = new();

    public MainWindow()
    {
        _scanner = new LinuxEmulatorScanner(_engine);
        Title = "PKF-SOS";
        try { Icon = new WindowIcon(new Avalonia.Media.Imaging.Bitmap(Avalonia.Platform.AssetLoader.Open(new Uri("avares://PKForge/assets/gameart/app_icon.png")))); }
        catch (Exception) { }
        Width = 1280;
        Height = 800;
        WindowState = WindowState.Maximized;
        MinWidth = 800;
        MinHeight = 500;
        Background = Ui.Bg;
        FontFamily = Ui.Font;
        XYFocus.SetNavigationModes(this, XYFocusNavigationModes.Enabled);
        var bar = _bar = new Border
        {
            Background = Ui.Panel,
            BorderBrush = Ui.Edge,
            BorderThickness = new Thickness(0, 2, 0, 0),
            Padding = new Thickness(24, 8),
            Child = _hintBar,
        };
        var layout = new Grid { RowDefinitions = new RowDefinitions("*,Auto") };
        layout.Children.Add(_host);
        Grid.SetRow(bar, 1);
        layout.Children.Add(bar);
        Content = layout;
        KeyDown += OnKeyDown;
        AddHandler(InputElement.GotFocusEvent, (s, e) => OnGotFocus(s, e), RoutingStrategies.Bubble);
        AddHandler(InputElement.LostFocusEvent, (s, e) => OnLostFocus(s, e), RoutingStrategies.Bubble);
        AddHandler(InputElement.PointerPressedEvent, (_, e) => { _padActive = false; GamepadInput.Note("mouse " + e.GetCurrentPoint(this).Properties.PointerUpdateKind); }, RoutingStrategies.Tunnel);
        _host.PropertyChanged += (_, e) =>
        {
            if (e.Property == ContentControl.ContentProperty) AfterScreenChange();
        };
        _pad.Pressed += button => Avalonia.Threading.Dispatcher.UIThread.Post(() => HandlePad(button));
        _pad.Start();
        Closed += (_, _) => _pad.Stop();
        ShowHome();
        _ = RescanAllAsync();
    }

    // ─────────────────────────────── Controller ───────────────────────────────

    private bool _wasActive;

    private static readonly Key[] Arrows = [Key.Up, Key.Down, Key.Left, Key.Right];

    /// <summary>A controller button: becomes the matching key press on whatever has focus.</summary>
    private void HandlePad(PadButton button)
    {
        var key = button switch
        {
            PadButton.Up => Key.Up,
            PadButton.Down => Key.Down,
            PadButton.Left => Key.Left,
            PadButton.Right => Key.Right,
            PadButton.A => Key.Enter,
            PadButton.B => Key.Escape,
            PadButton.X => Key.X,
            PadButton.Y => Key.Y,
            PadButton.L1 => Key.PageUp,
            PadButton.R1 => Key.PageDown,
            _ => Key.None,
        };
        if (key == Key.None) return;
        // On a desktop, ignore the pad while another window is in front. Gaming Mode (gamescope) never reports this
        // window as active, so if it has never been active, trust the pad.
        if (IsActive) _wasActive = true;
        else if (_wasActive) return;
        _padActive = true;
        var focused = FocusManager?.GetFocusedElement() as InputElement;
        if (focused is null || !focused.IsEffectivelyVisible)
        {
            if (Arrows.Contains(key) || key == Key.Enter)
            {
                FocusAt(0);
                return;
            }
        }
        if (key is Key.Up or Key.Down && TryVerticalFocus(key == Key.Down)) return;
        var target = focused ?? this;
        target.RaiseEvent(new KeyEventArgs { RoutedEvent = InputElement.KeyDownEvent, Key = key, Source = target });
        target.RaiseEvent(new KeyEventArgs { RoutedEvent = InputElement.KeyUpEvent, Key = key, Source = target });
    }

    /// <summary>
    /// Up/Down to the nearest control above or below, whatever its sideways position. Avalonia's own focus
    /// movement only looks inside a narrow cone, so a button at the right edge could have nothing "below" it
    /// even with a whole list of controls further down, and scrolling stopped there.
    /// </summary>
    private bool TryVerticalFocus(bool down)
    {
        if (FocusManager?.GetFocusedElement() is not Control focused || focused is TextBox or ComboBox or ListBox) return false;
        var origin = focused.TranslatePoint(new Point(focused.Bounds.Width / 2, focused.Bounds.Height / 2), this);
        if (origin is null) return false;
        InputElement? best = null;
        var bestScore = double.MaxValue;
        foreach (var candidate in Focusables())
        {
            if (ReferenceEquals(candidate, focused) || candidate is not Control c) continue;
            var at = c.TranslatePoint(new Point(c.Bounds.Width / 2, c.Bounds.Height / 2), this);
            if (at is null) continue;
            var dy = down ? at.Value.Y - origin.Value.Y : origin.Value.Y - at.Value.Y;
            if (dy < 6) continue;
            var score = dy + 0.35 * Math.Abs(at.Value.X - origin.Value.X);
            if (score < bestScore) { bestScore = score; best = candidate; }
        }
        const double step = 130;
        var direction = down ? 1 : -1;

        // Long pages: read through them with the D-pad, only moving focus once the target is on screen.
        ScrollViewer? Scroller(Control c)
        {
            foreach (var ancestor in c.GetVisualAncestors().OfType<ScrollViewer>())
                if (ancestor.Extent.Height > ancestor.Viewport.Height + 1) return ancestor;
            return null;
        }
        bool CanScroll(ScrollViewer sv) => down
            ? sv.Offset.Y < sv.Extent.Height - sv.Viewport.Height - 1
            : sv.Offset.Y > 1;
        bool Scroll(ScrollViewer sv)
        {
            if (!CanScroll(sv)) return false;
            var y = Math.Clamp(sv.Offset.Y + direction * step, 0, Math.Max(0, sv.Extent.Height - sv.Viewport.Height));
            sv.Offset = new Vector(sv.Offset.X, y);
            return true;
        }

        var ownScroller = Scroller(focused);
        if (best is null)
            return (ownScroller ?? _host.GetVisualDescendants().OfType<ScrollViewer>().FirstOrDefault(s => s.Extent.Height > s.Viewport.Height + 1)) is { } fallback && Scroll(fallback);

        var targetScroller = Scroller((Control)best);
        if (targetScroller is not null)
        {
            var at = ((Control)best).TranslatePoint(new Point(((Control)best).Bounds.Width / 2, ((Control)best).Bounds.Height / 2), targetScroller);
            var visible = at is { } p && p.Y >= -90 && p.Y <= targetScroller.Viewport.Height + 90;
            if (!visible && Scroll(targetScroller)) return true;
        }
        // Leaving the scrolled page (for example up to the Back button): finish reading it first.
        if (ownScroller is not null && !ReferenceEquals(targetScroller, ownScroller) && Scroll(ownScroller)) return true;

        best.Focus(NavigationMethod.Directional);
        return true;
    }

    private List<InputElement> Focusables() =>
        [.. _host.GetVisualDescendants().OfType<InputElement>().Where(c => c.Focusable && c.IsEffectivelyEnabled && c.IsEffectivelyVisible && c is not ScrollViewer)];

    private void FocusAt(int index)
    {
        var all = Focusables();
        if (all.Count == 0) return;
        all[Math.Clamp(index, 0, all.Count - 1)].Focus(NavigationMethod.Directional);
    }

    /// <summary>Highlights the focused button (only while the controller or keyboard is driving, never after a touch).</summary>
    private void OnGotFocus(object? sender, RoutedEventArgs e)
    {
        if (e.Source is not InputElement element) return;
        var all = Focusables();
        var at = all.IndexOf(element);
        if (at >= 0) _lastFocusIndex = at;
        if (!_padActive || element is not Button button) return;
        _focusMemo.Remove(button);
        _focusMemo.Add(button, new FocusMemo(button.BorderBrush, button.BorderThickness));
        button.BorderBrush = Brushes.White;
        button.BorderThickness = new Thickness(4);
    }

    private void OnLostFocus(object? sender, RoutedEventArgs e)
    {
        if (e.Source is Button button && _focusMemo.TryGetValue(button, out var memo))
        {
            button.BorderBrush = memo.Border;
            button.BorderThickness = memo.Thickness;
            _focusMemo.Remove(button);
        }
    }

    /// <summary>A screen was drawn: refresh the hint bar and, if a controller is in use, put focus back where it was.</summary>
    private void AfterScreenChange()
    {
        RefreshHints();
        if (!_padActive) return;
        var top = _screens.LastOrDefault();
        var keep = ReferenceEquals(top, _lastTop) && top is not null;
        _lastTop = top;
        var index = keep ? _lastFocusIndex : 0;
        Avalonia.Threading.Dispatcher.UIThread.Post(() => FocusAt(index), Avalonia.Threading.DispatcherPriority.Background);
    }

    private void RefreshHints()
    {
        _hintBar.Children.Clear();
        var top = _screens.LastOrDefault();
        var atHome = top is null && _back is null && _keys is null;
        _hintBar.Children.Add(Ui.PadHint("D-pad", "Move"));
        _hintBar.Children.Add(Ui.PadHint("A", "Select"));
        if (!atHome) _hintBar.Children.Add(Ui.PadHint("B", "Back"));
        if (top is not null)
            foreach (var (button, label) in top.PadHints)
                _hintBar.Children.Add(Ui.PadHint(button, label));
        else if (_keys is not null)
            _hintBar.Children.Add(Ui.PadHint("L1 / R1", "Box"));
        var space = new TextBlock { Text = OperatingSystem.IsWindows() ? "Keyboard and mouse also work" : "Steam + X: on-screen keyboard", FontSize = 14, Foreground = Ui.Dim, VerticalAlignment = VerticalAlignment.Center };
        _hintBar.Children.Add(space);
    }

    private void OnKeyDown(object? sender, KeyEventArgs e)
    {
        GamepadInput.Note("key " + e.Key + (e.KeyModifiers != KeyModifiers.None ? " + " + e.KeyModifiers : ""));
        // A real keyboard (or Steam's desktop layout) drives the same focus movement as the controller.
        if (Arrows.Contains(e.Key) || e.Key == Key.Enter)
        {
            _padActive = true;
            var focused = FocusManager?.GetFocusedElement() as InputElement;
            if (focused is null || !focused.IsEffectivelyVisible)
            {
                FocusAt(0);
                e.Handled = true;
                return;
            }
        }
        if (e.Key is Key.Up or Key.Down && e.KeyModifiers == KeyModifiers.None && !e.Handled && TryVerticalFocus(e.Key == Key.Down))
        {
            e.Handled = true;
            return;
        }
        if (e.Key is Key.X or Key.Y && e.Source is TextBox && !_padActive) return;
        if (_screens.Count > 0)
        {
            var top = _screens[^1];
            if (e.Key == Key.Escape) top.Escape();
            else if (!top.OnKey(e.Key)) return;
            e.Handled = true;
            return;
        }
        if (_keys?.Invoke(e.Key) == true)
        {
            e.Handled = true;
            return;
        }
        if (e.Key == Key.Escape && _back is not null)
        {
            _back();
            e.Handled = true;
        }
    }

    // ─────────────────────────────── Home ───────────────────────────────

    private void ShowHome()
    {
        _back = null;
        _keys = null;

        var root = new StackPanel { Margin = new Thickness(32, 24), Spacing = 18 };
        var heading = new StackPanel { Spacing = 0 };
        heading.Children.Add(Ui.Text("PKF-SOS", 42, true));
        heading.Children.Add(Ui.Text("Based on PKForge · A Vibe Coded Steam OS Port · v" + AppInfo.Version, 16, false, Ui.Dim));
        root.Children.Add(heading);
        _statusBlock = Ui.Text(_status, 16, false, Ui.Warn);
        _resultsPanel = new StackPanel();
        root.Children.Add(_resultsPanel);
        root.Children.Add(_statusBlock);
        RenderResults();
        var tools = new WrapPanel { ItemSpacing = 12, LineSpacing = 12 };
        tools.Children.Add(Ui.Btn("Living Dex Autopilot", OpenLivingDex, primary: true));
        tools.Children.Add(Ui.Btn("Bank", OpenBank));
        tools.Children.Add(Ui.Btn("Collection", OpenCollection));
        tools.Children.Add(Ui.Btn("Mystery Gifts", OpenEvents));
        tools.Children.Add(Ui.Btn("Bag", () => OpenBag()));
        tools.Children.Add(Ui.Btn("Trainer Card", () => OpenTrainer()));
        tools.Children.Add(Ui.Btn("Pokédex", () => OpenDex()));
        tools.Children.Add(Ui.Btn("Box Tools", OpenBoxTools));
        tools.Children.Add(Ui.Btn("Transfer", () => OpenTransfer(null, 0, -1, ShowHome)));
        tools.Children.Add(Ui.Btn("Generate", () => OpenGenerate(null, ShowHome)));
        tools.Children.Add(Ui.Btn("Restore Points", OpenRestore));
        tools.Children.Add(Ui.Btn("Park", OpenPark));
        root.Children.Add(tools);

        tools.Children.Add(Ui.Btn("Settings", ShowSettings));
        _host.Content = new ScrollViewer
        {
            Content = root,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
        };
    }

    private void ShowSettings()
    {
        _back = ShowHome;
        _keys = null;
        var root = new StackPanel { Margin = new Thickness(32, 24), Spacing = 18 };
        var header = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 18 };
        header.Children.Add(Ui.Btn("‹ Home", ShowHome));
        header.Children.Add(Ui.Text("Settings", 36, true));
        root.Children.Add(header);
        var items = new WrapPanel { ItemSpacing = 12, LineSpacing = 12 };
        items.Children.Add(Ui.Btn("Folders", ShowFolders, primary: true));
        items.Children.Add(Ui.Btn("UI Themes", ShowThemes));
        items.Children.Add(Ui.Btn("Controller Test", ShowPadTest));
        items.Children.Add(Ui.Btn("Credits & License", ShowCredits));
        root.Children.Add(items);
        root.Children.Add(Ui.Text("Folders: which folders are scanned for saves.\nUI Themes: change the colour of the app.", 16, false, Ui.Dim));
        _host.Content = new ScrollViewer { Content = root, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled };
    }

    private void ShowCredits()
    {
        _back = ShowSettings;
        _keys = null;
        var root = new StackPanel { Margin = new Thickness(32, 24), Spacing = 12, MaxWidth = 900 };
        var header = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 18 };
        header.Children.Add(Ui.Btn("‹ Settings", ShowSettings));
        header.Children.Add(Ui.Text("Credits & License", 36, true));
        root.Children.Add(header);
        root.Children.Add(Ui.Text("PKF-SOS version " + AppInfo.Version, 18, true, Ui.Gold));

        void Section(string title, string text)
        {
            root.Children.Add(Ui.Text(title, 22, true, Ui.Accent));
            root.Children.Add(Ui.Text(text, 17));
        }

        Section("About PKF-SOS",
            "PKF-SOS is based on PKForge. It is a fully AI-built (vibe coded) port of that project's code, with a new controller-first interface for Steam Deck / Linux and Windows.");
        Section("Not affiliated",
            "The original PKForge team has no affiliation with PKF-SOS, has not reviewed it and does not support it. Please do not report PKF-SOS problems to them. Original project: github.com/sofianeelhor/PKForge");
        Section("Licence",
            "GNU General Public License v3 or later, inherited from PKForge and PKHeX.Core. The source code is available in the PKF-SOS repository.");
        Section("Based on and built with",
            "PKForge by sofianeelhor: the original app and engine\n" +
            "PKHeX by Kaphotics and contributors: the save engine\n" +
            "PKHeX-Plugins / Auto Legality Mod by santacrab2: the offline legalizer\n" +
            "spritedmistery: the original PKForge look and logos\n" +
            "PKSM (FlagBrew): the pixel chrome the original UI builds on\n" +
            "SteamGridDB: game cover art and cartridge icons\n" +
            "Pokémon Showdown / Smogon and sprite artists: Pokémon sprites\n" +
            "Avalonia UI: the interface toolkit\n" +
            "NDS12 pixel font by Caveras (CC BY-NC-SA 3.0)");
        Section("Trademarks",
            "Pokémon and all related names are trademarks of Nintendo, Creatures Inc. and GAME FREAK inc. PKF-SOS is not affiliated with or endorsed by them. No game ROMs or saves are included.");
        _host.Content = new ScrollViewer { Content = root, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled };
    }

    private void ShowPadTest()
    {
        _back = ShowSettings;
        _keys = null;
        var root = new StackPanel { Margin = new Thickness(32, 24), Spacing = 12 };
        var header = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 18 };
        header.Children.Add(Ui.Btn("‹ Settings", ShowSettings));
        header.Children.Add(Ui.Text("Controller Test", 36, true));
        root.Children.Add(header);
        root.Children.Add(Ui.Text("Press buttons now. Each press appears under 'Last inputs'. Take a photo of this screen if something does not respond.", 16, false, Ui.Dim));
        root.Children.Add(Ui.Text("Input devices", 22, true));
        var devices = Ui.Text("", 14, false, Ui.Gold);
        root.Children.Add(devices);
        root.Children.Add(Ui.Text("Last inputs", 22, true));
        var trace = Ui.Text("", 16);
        root.Children.Add(trace);
        var content = new ScrollViewer { Content = root, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled };
        _host.Content = content;
        var timer = new Avalonia.Threading.DispatcherTimer { Interval = TimeSpan.FromMilliseconds(300) };
        timer.Tick += (_, _) =>
        {
            if (!ReferenceEquals(_host.Content, content)) { timer.Stop(); return; }
            devices.Text = string.Join("\n", GamepadInput.Devices);
            var lines = GamepadInput.Trace;
            trace.Text = lines.Count == 0 ? "(nothing yet)" : string.Join("\n", lines.Reverse());
        };
        timer.Start();
    }

    private void ShowThemes()
    {
        _back = ShowSettings;
        _keys = null;
        var root = new StackPanel { Margin = new Thickness(32, 24), Spacing = 18 };
        var header = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 18 };
        header.Children.Add(Ui.Btn("‹ Settings", ShowSettings));
        header.Children.Add(Ui.Text("UI Themes", 36, true));
        root.Children.Add(header);
        root.Children.Add(Ui.Text("Tap a theme to use it. It is remembered next time.", 16, false, Ui.Dim));
        var grid = new WrapPanel { ItemSpacing = 14, LineSpacing = 14 };
        foreach (var theme in Ui.Themes)
        {
            var chosen = theme;
            Control Swatch(string colour) => new Border { Width = 34, Height = 34, CornerRadius = new CornerRadius(6), Background = new SolidColorBrush(Color.Parse(colour)) };
            var swatches = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 6 };
            foreach (var c in new[] { theme.Bg, theme.Panel, theme.PanelHi, theme.Blue, theme.Accent }) swatches.Children.Add(Swatch(c));
            var content = new StackPanel { Spacing = 8 };
            content.Children.Add(Ui.Text(theme.Name + (theme.Name == Ui.CurrentTheme ? "  ✓" : ""), 22, true));
            content.Children.Add(swatches);
            var button = new Button
            {
                Content = content,
                Padding = new Thickness(16, 12),
                MinWidth = 280,
                MinHeight = 96,
                Background = Ui.Panel,
                BorderBrush = theme.Name == Ui.CurrentTheme ? Ui.Accent : Ui.Edge,
                BorderThickness = new Thickness(3),
                CornerRadius = new CornerRadius(8),
            };
            button.Click += (_, _) =>
            {
                Ui.Apply(chosen.Name);
                _settings.Theme = chosen.Name;
                SettingsStore.Save(_settings);
                Background = Ui.Bg;
                _bar.Background = Ui.Panel;
                _bar.BorderBrush = Ui.Edge;
                ShowThemes();
            };
            grid.Children.Add(button);
        }
        root.Children.Add(grid);
        _host.Content = new ScrollViewer { Content = root, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled };
    }

    /// <summary>The folders menu: which folders PKForge watches, and adding new ones.</summary>
    private void ShowFolders()
    {
        _back = ShowSettings;
        _keys = null;

        var root = new StackPanel { Margin = new Thickness(32, 24), Spacing = 18 };
        var back = Ui.Btn("‹ Settings", ShowSettings);
        var header = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 18 };
        header.Children.Add(back);
        header.Children.Add(Ui.Text("Folders", 36, true));
        root.Children.Add(header);
        _statusBlock = Ui.Text(_status, 16, false, Ui.Warn);
        root.Children.Add(_statusBlock);

        if (_settings.Folders.Count > 0)
        {
            root.Children.Add(Ui.Text("Your folders", 24, true));
            foreach (var folder in _settings.Folders.ToList())
                root.Children.Add(FolderRow(folder));
        }

        root.Children.Add(Ui.Text("Add a folder that has your saves", 24, true));
        _pathBox = new TextBox
        {
            Text = DefaultFolder(),
            FontSize = 20,
            MinHeight = 56,
            VerticalContentAlignment = VerticalAlignment.Center,
        };
        var browse = Ui.Btn("Browse…", () => _ = BrowseAsync());
        browse.Margin = new Thickness(12, 0, 0, 0);
        DockPanel.SetDock(browse, Dock.Right);
        var pathRow = new DockPanel { LastChildFill = true };
        pathRow.Children.Add(browse);
        pathRow.Children.Add(_pathBox);
        root.Children.Add(pathRow);

        var suggestions = SuggestedFolders().ToList();
        if (suggestions.Count > 0)
        {
            root.Children.Add(Ui.Text("Folders found on this device (tap one to use it):", 16, false, Ui.Dim));
            var chips = new WrapPanel();
            foreach (var path in suggestions)
            {
                var chip = Ui.Btn(path.Replace(AppPaths.Home, "~"), () => _pathBox.Text = path);
                chip.MinHeight = 44;
                chip.FontSize = 16;
                chip.Margin = new Thickness(0, 0, 10, 10);
                chips.Children.Add(chip);
            }
            root.Children.Add(chips);
        }

        root.Children.Add(Ui.Text("What kind of saves are in it?", 16, false, Ui.Dim));
        _kindBox = new ComboBox
        {
            ItemsSource = KindChoices.Select(k => k.Label).ToList(),
            SelectedIndex = 0,
            FontSize = 20,
            MinHeight = 56,
            HorizontalAlignment = HorizontalAlignment.Stretch,
        };
        root.Children.Add(_kindBox);
        root.Children.Add(Ui.Btn("Add folder and scan", () => _ = AddFolderAsync(), primary: true));

        _host.Content = new ScrollViewer
        {
            Content = root,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
        };
    }


    private void OpenLivingDex()
    {
        _back = null;
        _keys = null;
        LivingDexPage? page = null;
        page = new LivingDexPage(_host, _settings, () =>
        {
            _screens.Remove(page!);
            ShowHome();
        });
        _screens.Add(page);
        page.Start();
    }

    private void OpenBank()
    {
        _back = null;
        _keys = null;
        BankPage? page = null;
        page = new BankPage(_host, _sprites, OpenEditor, () =>
        {
            _screens.Remove(page!);
            ShowHome();
        }, () =>
        {
            _screens.Remove(page!);
            OpenBankTransfer(OpenBank);
        });
        _screens.Add(page);
        page.Start();
    }

    private void OpenBankTransfer(Action? after = null)
    {
        _back = null;
        _keys = null;
        BankTransferPage? page = null;
        page = new BankTransferPage(_host, () =>
        {
            _screens.Remove(page!);
            (after ?? ShowHome)();
        });
        _screens.Add(page);
        page.Start();
    }

    private void OpenBag(DetectedSave? preset = null, Action? after = null)
    {
        _back = null;
        _keys = null;
        BagPage? page = null;
        page = new BagPage(_host, () =>
        {
            _screens.Remove(page!);
            (after ?? ShowHome)();
        }, preset);
        _screens.Add(page);
        page.Start();
    }

    private void OpenTrainer(DetectedSave? preset = null, Action? after = null)
    {
        _back = null;
        _keys = null;
        TrainerPage? page = null;
        page = new TrainerPage(_host, _sprites, _settings, () =>
        {
            _screens.Remove(page!);
            (after ?? ShowHome)();
        }, preset);
        _screens.Add(page);
        page.Start();
    }

    private void OpenDex(DetectedSave? preset = null, Action? after = null)
    {
        _back = null;
        _keys = null;
        DexPage? page = null;
        page = new DexPage(_host, _sprites, () =>
        {
            _screens.Remove(page!);
            (after ?? ShowHome)();
        }, preset);
        _screens.Add(page);
        page.Start();
    }

    private void OpenParty(DetectedSave save, Action after)
    {
        _back = null;
        _keys = null;
        PartyPage? page = null;
        page = new PartyPage(_host, _sprites, save, OpenEditor, () =>
        {
            _screens.Remove(page!);
            after();
        });
        _screens.Add(page);
        page.Start();
    }

    /// <summary>What a tapped save thumbnail opens: the ways into that one game.</summary>
    private void ShowSaveHub(DetectedSave save)
    {
        _back = ShowHome;
        _keys = null;
        var back = Ui.Btn("‹ Home", ShowHome);
        back.HorizontalAlignment = HorizontalAlignment.Left;

        var art = GameArtStore.Get(save.ArtLabel ?? save.GameLabel);
        var heading = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center, Spacing = 6 };
        if (art is not null) heading.Children.Add(new Image { Source = art, Width = 140, Height = 140, Stretch = Stretch.Uniform });
        var title = Ui.Text(save.GameLabel.Replace("Pokémon ", ""), 34, true);
        title.TextAlignment = TextAlignment.Center;
        heading.Children.Add(title);
        if (!string.IsNullOrWhiteSpace(save.TrainerName))
        {
            var trainer = Ui.Text(save.TrainerName!, 20, false, Ui.Dim);
            trainer.TextAlignment = TextAlignment.Center;
            heading.Children.Add(trainer);
        }

        var choices = new WrapPanel { ItemSpacing = 14, LineSpacing = 14, HorizontalAlignment = HorizontalAlignment.Center };
        void Add(string text, Action go, bool primary = false)
        {
            var b = Ui.Btn(text, go, primary);
            b.MinWidth = 210; b.MinHeight = 76; b.FontSize = 24;
            choices.Children.Add(b);
        }
        Add("Box", () => OpenSave(save), primary: true);
        Add("Collection", OpenCollection);
        Add("Party", () => OpenParty(save, () => ShowSaveHub(save)));
        Add("Bag", () => OpenBag(save, () => ShowSaveHub(save)));
        Add("Trainer Card", () => OpenTrainer(save, () => ShowSaveHub(save)));
        Add("Pokédex", () => OpenDex(save, () => ShowSaveHub(save)));

        var column = new StackPanel { Spacing = 28, HorizontalAlignment = HorizontalAlignment.Center, MaxWidth = 900 };
        column.Children.Add(heading);
        column.Children.Add(choices);

        var root = new DockPanel { Margin = new Thickness(32, 24) };
        DockPanel.SetDock(back, Dock.Top);
        root.Children.Add(back);
        root.Children.Add(new ScrollViewer
        {
            Content = new Grid { Children = { column } },
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
        });
        _host.Content = root;
    }

    private void OpenBoxTools()
    {
        _back = null;
        _keys = null;
        BoxToolsPage? page = null;
        page = new BoxToolsPage(_host, _sprites, () =>
        {
            _screens.Remove(page!);
            ShowHome();
        });
        _screens.Add(page);
        page.Start();
    }

    private void OpenGenerate(int? species, Action after)
    {
        _back = null;
        _keys = null;
        GeneratePage? page = null;
        page = new GeneratePage(_host, _sprites, species, () =>
        {
            _screens.Remove(page!);
            after();
        });
        _screens.Add(page);
        page.Start();
    }

    private void OpenTransfer(DetectedSave? from, int box, int slot, Action after)
    {
        _back = null;
        _keys = null;
        TransferPage? page = null;
        page = new TransferPage(_host, _sprites, () =>
        {
            _screens.Remove(page!);
            after();
        }, from, box, slot);
        _screens.Add(page);
        page.Start();
    }

    private void OpenRestore()
    {
        _back = null;
        _keys = null;
        RestorePage? page = null;
        page = new RestorePage(_host, () =>
        {
            _screens.Remove(page!);
            ShowHome();
        });
        _screens.Add(page);
        page.Start();
    }

    private void OpenPark()
    {
        _back = null;
        _keys = null;
        ParkPage? page = null;
        page = new ParkPage(_host, _sprites, () =>
        {
            _screens.Remove(page!);
            ShowHome();
        });
        _screens.Add(page);
        page.Start();
    }

    private void OpenKeyItemEvents()
    {
        _back = null;
        _keys = null;
        KeyItemEventsPage? page = null;
        page = new KeyItemEventsPage(_host, () =>
        {
            _screens.Remove(page!);
            OpenEvents();
        });
        _screens.Add(page);
        page.Start();
    }

    private void OpenEvents()
    {
        _back = null;
        _keys = null;
        EventsPage? page = null;
        page = new EventsPage(_host, _sprites, () =>
        {
            _screens.Remove(page!);
            ShowHome();
        }, () =>
        {
            _screens.Remove(page!);
            OpenKeyItemEvents();
        });
        _screens.Add(page);
        page.Start();
    }

    private void OpenCollection()
    {
        _back = null;
        _keys = null;
        CollectionPage? page = null;
        page = new CollectionPage(_host, _sprites, OpenEditor, species => OpenGenerate(species, () => page!.Start()),
            (save, box, slot) => OpenTransfer(save, box, slot, () => page!.Start()), () =>
        {
            _screens.Remove(page!);
            ShowHome();
        });
        _screens.Add(page);
        page.Start();
    }

    /// <summary>Opens the Pokémon editor on top of whatever is showing; <paramref name="after"/> runs when it closes.</summary>
    private void OpenEditor(EditTarget target, Action<bool> after)
    {
        EditorPage? page = null;
        page = new EditorPage(_host, _sprites, target, saved =>
        {
            _screens.Remove(page!);
            after(saved);
        });
        _screens.Add(page);
        page.Start();
    }

    /// <summary>Scans every remembered folder at startup so the autopilot has saves to work with.</summary>
    private async Task RescanAllAsync()
    {
        foreach (var folder in _settings.Folders.ToList())
        {
            try
            {
                EmulatorKind? kind = folder.Kind < 0 ? null : (EmulatorKind)folder.Kind;
                var report = await _scanner.ScanAsync(folder.Path, kind, CancellationToken.None);
                Shelf.Set(folder.Path, report.Saves);
                RenderResults();
            }
            catch (Exception) { /* a missing folder is just skipped */ }
        }
    }

    private static string DefaultFolder()
    {
        var desktop = Path.Combine(AppPaths.Home, "Desktop");
        return Directory.Exists(desktop) ? desktop : AppPaths.Home;
    }

    /// <summary>Places where Steam Deck emulator setups usually keep saves; only ones that exist are offered.</summary>
    private static IEnumerable<string> SuggestedFolders()
    {
        var home = AppPaths.Home;
        string[] candidates =
        [
            Path.Combine(home, "Desktop"),
            Path.Combine(home, "Emulation", "saves"),
            Path.Combine(home, "Emulation", "saves", "retroarch", "saves"),
            Path.Combine(home, ".local", "share", "azahar-emu"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Azahar"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Azahar", "sdmc"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Citra"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "RetroArch", "saves"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "RetroArch", "saves"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Emulation"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "melonDS"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Dolphin Emulator"),
            Path.Combine(home, ".var", "app", "org.azahar_emu.Azahar", "data", "azahar-emu"),
            Path.Combine(home, ".config", "retroarch", "saves"),
            Path.Combine(home, ".var", "app", "org.libretro.RetroArch", "config", "retroarch", "saves"),
        ];
        return candidates.Where(Directory.Exists);
    }

    private Control FolderRow(WatchedFolder folder)
    {
        var kindText = folder.Kind < 0
            ? "Auto-detect"
            : KindChoices.FirstOrDefault(k => k.Kind == folder.Kind).Label ?? "Custom";

        var info = new StackPanel { Spacing = 2, VerticalAlignment = VerticalAlignment.Center };
        info.Children.Add(Ui.Text(folder.Path.Replace(AppPaths.Home, "~"), 20, true));
        info.Children.Add(Ui.Text(kindText, 15, false, Ui.Dim));

        var scan = Ui.Btn("Scan", () => _ = ScanAsync(folder), primary: true);
        scan.Margin = new Thickness(10, 0, 0, 0);
        var remove = Ui.Btn("Remove", () =>
        {
            _settings.Folders.Remove(folder);
            Shelf.Forget(folder.Path);
            SettingsStore.Save(_settings);
            ShowFolders();
        });
        remove.Margin = new Thickness(10, 0, 0, 0);

        var buttons = new StackPanel { Orientation = Orientation.Horizontal };
        buttons.Children.Add(scan);
        buttons.Children.Add(remove);
        DockPanel.SetDock(buttons, Dock.Right);

        var row = new DockPanel { LastChildFill = true };
        row.Children.Add(buttons);
        row.Children.Add(info);

        return new Border
        {
            Background = Ui.Panel,
            CornerRadius = new CornerRadius(12),
            Padding = new Thickness(18, 12),
            Child = row,
        };
    }

    private async Task BrowseAsync()
    {
        try
        {
            var picked = await StorageProvider.OpenFolderPickerAsync(new FolderPickerOpenOptions
            {
                Title = "Choose the folder with your saves",
                AllowMultiple = false,
            });
            if (picked.Count > 0 && picked[0].TryGetLocalPath() is { } path)
                _pathBox.Text = path;
        }
        catch (Exception error)
        {
            SetStatus("The folder chooser could not open (" + error.Message + "). Type the path instead.");
        }
    }

    private async Task AddFolderAsync()
    {
        var path = (_pathBox.Text ?? "").Trim();
        if (path.StartsWith('~'))
            path = Path.Combine(AppPaths.Home, path.TrimStart('~').TrimStart('/'));
        if (!Directory.Exists(path))
        {
            SetStatus("That folder doesn't exist: " + path);
            return;
        }

        var kind = KindChoices[Math.Max(0, _kindBox.SelectedIndex)].Kind;
        var existing = _settings.Folders.FirstOrDefault(f => f.Path == path);
        if (existing is null)
        {
            existing = new WatchedFolder { Path = path, Kind = kind };
            _settings.Folders.Add(existing);
        }
        else
        {
            existing.Kind = kind;
        }
        SettingsStore.Save(_settings);
        ShowFolders();
        await ScanAsync(existing);
    }

    private async Task ScanAsync(WatchedFolder folder)
    {
        _scanCts?.Cancel();
        _scanCts = new CancellationTokenSource();
        var token = _scanCts.Token;

        SetStatus("Scanning " + folder.Path.Replace(AppPaths.Home, "~") + " …");
        try
        {
            EmulatorKind? kind = folder.Kind < 0 ? null : (EmulatorKind)folder.Kind;
            var report = await _scanner.ScanAsync(folder.Path, kind, token);
            if (token.IsCancellationRequested) return;

            _lastSaves = report.Saves;
            Shelf.Set(folder.Path, report.Saves);
            if (report.Saves.Count > 0)
            {
                SetStatus($"Found {report.Saves.Count} save(s). Tap one to open it.");
            }
            else
            {
                var why = $"No saves found. Looked at {report.FilesSeen} file(s).";
                if (report.Rejected.Count > 0)
                    why += " These looked like saves but could not be read: " + string.Join(", ", report.Rejected.Take(5)) + ".";
                if (report.Log.Count > 0)
                    why += " " + report.Log[^1];
                SetStatus(why);
            }
            RenderResults();
        }
        catch (OperationCanceledException)
        {
            // a newer scan replaced this one
        }
        catch (Exception error)
        {
            SetStatus("Scan failed: " + error.Message);
        }
    }

    private void SetStatus(string text)
    {
        _status = text;
        _statusBlock.Text = text;
    }

    private void RenderResults()
    {
        _resultsPanel.Children.Clear();
        var saves = Shelf.All;
        if (saves.Count == 0)
        {
            _resultsPanel.Children.Add(Ui.Text("No saves yet. Add a folder below and they will appear here as game covers.", 18, false, Ui.Dim));
            return;
        }
        var heading = Ui.Text("Your games", 18, true, Ui.Dim);
        heading.HorizontalAlignment = HorizontalAlignment.Center;
        heading.TextAlignment = TextAlignment.Center;
        heading.Margin = new Thickness(0, 0, 0, 8);
        _resultsPanel.Children.Add(heading);
        var row = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 12, HorizontalAlignment = HorizontalAlignment.Center };
        foreach (var save in saves)
            row.Children.Add(SaveThumb(save));
        _resultsPanel.Children.Add(new ScrollViewer
        {
            Content = row,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
            VerticalScrollBarVisibility = ScrollBarVisibility.Disabled,
        });
    }

    /// <summary>One synced save as a game-cover card; tap it to open the save.</summary>
    private Control SaveThumb(DetectedSave save)
    {
        var card = new StackPanel { Spacing = 4, Width = 150 };
        var art = GameArtStore.Get(save.ArtLabel ?? save.GameLabel);
        card.Children.Add(art is null
            ? new Border { Width = 128, Height = 128, Background = Ui.Bg, CornerRadius = new CornerRadius(6), Child = Ui.Text("?", 48, true, Ui.Dim) }
            : new Image { Source = art, Width = 128, Height = 128, Stretch = Stretch.Uniform });
        var title = Ui.Text(save.GameLabel.Replace("Pokémon ", ""), 14, true);
        title.TextAlignment = TextAlignment.Center;
        title.MaxHeight = 38;
        card.Children.Add(title);
        if (!string.IsNullOrWhiteSpace(save.TrainerName))
        {
            var trainer = Ui.Text(save.TrainerName!, 13, false, Ui.Dim);
            trainer.TextAlignment = TextAlignment.Center;
            card.Children.Add(trainer);
        }
        var button = new Button
        {
            Content = card,
            Padding = new Thickness(10, 10),
            Background = Ui.Panel,
            BorderBrush = Ui.Edge,
            BorderThickness = new Thickness(2),
            CornerRadius = new CornerRadius(8),
            HorizontalContentAlignment = HorizontalAlignment.Center,
        };
        button.Click += (_, _) => ShowSaveHub(save);
        return button;
    }

    // ─────────────────────────────── Save viewer ───────────────────────────────

    private void OpenSave(DetectedSave save, int startBox = 0, SlotSummary? reselect = null)
    {
        SaveSnapshot snapshot;
        try
        {
            var bytes = AppPaths.ReadShared(save.DocumentId);
            snapshot = _engine.Open(bytes, save.EngineHint);
        }
        catch (Exception error)
        {
            SetStatus("Could not open that save: " + error.Message);
            return;
        }
        ShowSave(save, snapshot, startBox, reselect);
    }

    private string SpeciesName(int species) =>
        species >= 0 && species < _data.SpeciesNames.Count && _data.SpeciesNames[species].Length > 0
            ? _data.SpeciesNames[species]
            : "#" + species;

    private void ShowSave(DetectedSave save, SaveSnapshot snapshot, int startBox = 0, SlotSummary? reselect = null)
    {
        var boxes = snapshot.Slots
            .GroupBy(s => s.Box)
            .OrderBy(g => g.Key)
            .Select(g => g.OrderBy(s => s.Slot).ToList())
            .ToList();
        if (boxes.Count == 0)
        {
            SetStatus("This save has no boxes to show.");
            return;
        }

        _back = () => ShowSaveHub(save);
        var boxIndex = Math.Clamp(startBox, 0, boxes.Count - 1);
        SlotSummary? selected = reselect is null ? null
            : boxes[boxIndex].FirstOrDefault(x => x.Box == reselect.Box && x.Slot == reselect.Slot);
        string? editError = null;

        async void StartEdit(SlotSummary slot)
        {
            try
            {
                var target = await EditTarget.ForSaveAsync(save, slot.Box, slot.Slot);
                OpenEditor(target, _ => OpenSave(save, boxIndex, slot));
            }
            catch (Exception error)
            {
                editError = "Could not open the editor: " + error.Message;
                RenderDetail();
            }
        }

        var grid = new UniformGrid { Columns = 6 };
        var detail = new StackPanel { Spacing = 10 };
        var boxLabel = Ui.Text("", 24, true);
        boxLabel.HorizontalAlignment = HorizontalAlignment.Center;
        boxLabel.VerticalAlignment = VerticalAlignment.Center;

        void RenderBox()
        {
            boxLabel.Text = $"Box {boxIndex + 1} of {boxes.Count}";
            grid.Children.Clear();
            foreach (var slot in boxes[boxIndex])
            {
                var current = slot;
                var isSelected = selected is { } s && s.Box == current.Box && s.Slot == current.Slot;
                grid.Children.Add(SlotTile(current, isSelected, () =>
                {
                    selected = current;
                    RenderBox();
                    RenderDetail();
                }));
            }
        }

        void RenderDetail()
        {
            detail.Children.Clear();
            var slot = selected;
            if (slot is null || slot.Species is not int species || species <= 0)
            {
                detail.Children.Add(Ui.Text("Tap a Pokémon to see it here.", 20, false, Ui.Dim));
                return;
            }

            var sprite = _sprites.GetFilled(slot.Look);
            if (sprite is not null)
            {
                detail.Children.Add(new Image
                {
                    Source = sprite,
                    Width = 340,
                    Height = 280,
                    Stretch = Stretch.Uniform,
                    HorizontalAlignment = HorizontalAlignment.Center,
                });
            }
            detail.Children.Add(Ui.Text(SpeciesName(species), 30, true));
            if (!string.IsNullOrEmpty(slot.Nickname))
                detail.Children.Add(Ui.Text("Nickname: " + slot.Nickname, 20));
            if (slot.Form > 0)
                detail.Children.Add(Ui.Text("Form " + slot.Form, 18, false, Ui.Dim));
            if (slot.IsShiny)
                detail.Children.Add(Ui.Text("★ Shiny", 20, true, Ui.Gold));
            if (slot.IsEgg)
                detail.Children.Add(Ui.Text("Egg", 20, false, Ui.Dim));
            if (!slot.IsLegal)
                detail.Children.Add(Ui.Text("Not legal according to the checker", 18, false, Ui.Warn));
            detail.Children.Add(Ui.Text($"Box {slot.Box + 1}, slot {slot.Slot + 1}", 16, false, Ui.Dim));
            if (editError is not null)
                detail.Children.Add(Ui.Text(editError, 16, false, Ui.Warn));
            detail.Children.Add(Ui.Btn("Edit this Pokémon", () => StartEdit(slot), primary: true));
        }

        void Go(int delta)
        {
            boxIndex = (boxIndex + delta + boxes.Count) % boxes.Count;
            selected = null;
            RenderBox();
            RenderDetail();
        }

        _keys = key =>
        {
            switch (key)
            {
                case Key.PageUp:
                    Go(-1);
                    return true;
                case Key.PageDown:
                    Go(1);
                    return true;
                default:
                    return false;
            }
        };

        // header
        var back = Ui.Btn("‹ Back", () => ShowSaveHub(save));
        back.Margin = new Thickness(0, 0, 18, 0);
        DockPanel.SetDock(back, Dock.Left);
        var titles = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
        titles.Children.Add(Ui.Text(save.GameLabel, 28, true));
        titles.Children.Add(Ui.Text($"{save.TrainerName} · {save.PlayTime} · Generation {snapshot.Generation}", 16, false, Ui.Dim));
        var header = new DockPanel { Margin = new Thickness(0, 0, 0, 12) };
        header.Children.Add(back);
        header.Children.Add(titles);
        DockPanel.SetDock(header, Dock.Top);

        // box picker
        var prev = Ui.Btn("‹ Prev", () => Go(-1));
        DockPanel.SetDock(prev, Dock.Left);
        var next = Ui.Btn("Next ›", () => Go(1));
        DockPanel.SetDock(next, Dock.Right);
        var nav = new DockPanel { Margin = new Thickness(0, 0, 0, 12) };
        nav.Children.Add(prev);
        nav.Children.Add(next);
        nav.Children.Add(boxLabel);
        DockPanel.SetDock(nav, Dock.Top);

        // details
        var detailBorder = new Border
        {
            Width = 380,
            Padding = new Thickness(20),
            Margin = new Thickness(16, 0, 0, 0),
            Background = Ui.Panel,
            CornerRadius = new CornerRadius(12),
            Child = detail,
        };
        DockPanel.SetDock(detailBorder, Dock.Right);

        var root = new DockPanel { Margin = new Thickness(24) };
        root.Children.Add(header);
        root.Children.Add(nav);
        root.Children.Add(detailBorder);
        root.Children.Add(grid);

        RenderBox();
        RenderDetail();
        _host.Content = root;
    }

    private Control SlotTile(SlotSummary slot, bool selected, Action onTap)
    {
        var content = new Grid();
        if (slot.Species is int species && species > 0)
        {
            var sprite = _sprites.GetFilled(slot.Look);
            if (sprite is not null)
            {
                content.Children.Add(new Image
                {
                    Source = sprite,
                    Stretch = Stretch.Uniform,
                    Margin = new Thickness(0),
                });
            }
            else
            {
                var name = Ui.Text(SpeciesName(species), 13, false, Ui.Dim);
                name.HorizontalAlignment = HorizontalAlignment.Center;
                name.VerticalAlignment = VerticalAlignment.Center;
                content.Children.Add(name);
            }

            if (slot.IsShiny)
            {
                var star = Ui.Text("★", 18, true, Ui.Gold);
                star.HorizontalAlignment = HorizontalAlignment.Right;
                star.VerticalAlignment = VerticalAlignment.Top;
                star.Margin = new Thickness(0, 2, 6, 0);
                content.Children.Add(star);
            }
            if (!slot.IsLegal)
            {
                var warn = Ui.Text("!", 18, true, Ui.Warn);
                warn.HorizontalAlignment = HorizontalAlignment.Left;
                warn.VerticalAlignment = VerticalAlignment.Top;
                warn.Margin = new Thickness(6, 2, 0, 0);
                content.Children.Add(warn);
            }
        }

        var button = new Button
        {
            Content = content,
            Height = 104,
            Margin = new Thickness(3),
            Padding = new Thickness(0),
            HorizontalAlignment = HorizontalAlignment.Stretch,
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            VerticalContentAlignment = VerticalAlignment.Stretch,
            Background = selected ? Ui.PanelHi : Ui.Panel,
            BorderBrush = selected ? Ui.Accent : Ui.Clear,
            BorderThickness = new Thickness(selected ? 3 : 1),
            CornerRadius = new CornerRadius(8),
        };
        button.Click += (_, _) => onTap();
        return button;
    }
}
