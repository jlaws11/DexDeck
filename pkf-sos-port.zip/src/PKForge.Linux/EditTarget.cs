using PKForge.Domain;
using PKForge.Linux.Services;

namespace PKForge.Linux;

/// <summary>
/// One Pokémon being edited, plus how to put the result back. The editor only ever works on a
/// throwaway engine session: nothing is written anywhere until <see cref="SaveAsync"/> runs.
/// </summary>
public sealed class EditTarget
{
    public required ISaveEngineSession Session { get; init; }
    public required int Box { get; init; }
    public required int Slot { get; init; }
    /// <summary>Where it lives, for the screens ("Pokémon FireRed", "the Bank").</summary>
    public required string Where { get; init; }
    public required bool IsBank { get; init; }
    /// <summary>Set when saving is not possible (read-only identity, risky layout); editing is then preview-only.</summary>
    public string? Refusal { get; init; }
    public string? Caution { get; init; }
    /// <summary>Writes the change safely and returns a message for the player.</summary>
    public required Func<Task<string>> SaveAsync { get; init; }

    // ───────────────────────── from a game save ─────────────────────────

    public static async Task<EditTarget> ForSaveAsync(DetectedSave save, int box, int slot)
    {
        var bytes = (await Svc.Access.ReadAsync(save.DocumentId)).ToArray();
        var session = Svc.Engine.OpenSession(bytes, save.EngineHint, save.Format);
        var snapshot = session.Snapshot;
        var refusal = Svc.Writer.WhyWritesAreRefused(save.DocumentId, snapshot);

        return new EditTarget
        {
            Session = session,
            Box = box,
            Slot = slot,
            Where = save.GameLabel,
            IsBank = false,
            Refusal = refusal,
            Caution = Shelf.Caution(save),
            SaveAsync = async () =>
            {
                // An emulator that rewrote the file since we opened it would be overwritten: refuse.
                var current = await Svc.Access.ReadAsync(save.DocumentId);
                if (!current.Span.SequenceEqual(bytes))
                    throw new InvalidOperationException(
                        "The save changed on disk since you opened the editor. Is the emulator running? Close it and open the editor again.");

                var candidate = session.Serialize();
                var receipt = await Svc.Writer.WriteScopedAsync(
                    save.DocumentId, snapshot, candidate, WriteScope.Only(new SlotRef(box, slot)),
                    "Edited a Pokémon in PKForge");
                if (receipt.Changed) Svc.Sessions.MarkWritten(save.DocumentId, candidate);
                return receipt.Changed
                    ? "Saved. A restore point of the original was made first."
                    : "Nothing was different, so nothing was written.";
            },
        };
    }

    // ───────────────────────── from the Bank ─────────────────────────

    public static EditTarget ForBank(BankEntry entry)
    {
        var data = Svc.Bank.GetData(entry.Id);
        var name = string.IsNullOrWhiteSpace(entry.Info.Nickname) ? Svc.SpeciesName(entry.Info.Species) : entry.Info.Nickname;
        var session = Svc.Engine.OpenEntitySession(data, name, entry.Info.Format)
            ?? throw new InvalidOperationException("This Pokémon's data could not be opened for editing.");

        return new EditTarget
        {
            Session = session,
            Box = 0,
            Slot = 0,
            Where = "the Bank",
            IsBank = true,
            SaveAsync = () =>
            {
                var export = session.ExportSlot(0, 0);
                var info = Svc.Engine.TryDescribeEntity(export.Data, entry.Info.SourceName, export.Format)
                    ?? throw new InvalidOperationException("The edited Pokémon could not be read back.");
                Svc.Bank.Replace(entry.Id, export.Data, info with { SourceName = entry.Info.SourceName });
                return Task.FromResult("Saved to the Bank.");
            },
        };
    }
}
