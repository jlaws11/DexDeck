using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Layout;
using PKForge.Domain;
using PKForge.Engine;
using PKForge.Linux.Services;

namespace PKForge.Linux;

/// <summary>
/// The Living Dex Autopilot: fills one living dex (a save or the Bank) with Pokémon you already own.
/// Four steps, and nothing is written until the last one:
/// 1) choose where and how, 2) read the plan, 3) dry run (done in memory), 4) apply.
/// Every save gets a restore point first; a failure rolls everything back.
/// </summary>
public sealed class LivingDexPage : IScreen
{
    private readonly ContentControl _host;
    private readonly Action _close;
    private readonly AppSettings _settings;

    private LivingDexShelf? _shelf;
    private string? _destinationId;
    private bool _shiny, _forms, _lastCopies, _party, _copy;
    private bool _downgrades = true;
    private LivingDexPlan? _plan;
    private LivingDexStaging? _staging;
    private CancellationTokenSource? _cts;

    public LivingDexPage(ContentControl host, AppSettings settings, Action close)
    {
        _host = host;
        _settings = settings;
        _close = close;
    }

    public void Escape()
    {
        if (_staging is not null) { _staging.Dispose(); _staging = null; }
        _cts?.Cancel();
        _close();
    }

    // ───────────────────────── step 1: read the shelf ─────────────────────────

    public async void Start()
    {
        Show(Frame("Living Dex Autopilot", Ui.Text("Reading your saves…", 22)));
        try
        {
            _cts = new CancellationTokenSource();
            var progress = new Progress<string>(line => Show(Frame("Living Dex Autopilot", Ui.Text(line, 22))));
            _shelf = await Shelf.ReadAsync(progress, _cts.Token);
            ShowSetup();
        }
        catch (Exception error)
        {
            Show(Frame("Living Dex Autopilot", Ui.Text("Could not read your saves: " + error.Message, 20, false, Ui.Warn)));
        }
    }

    // ───────────────────────── step 2: choose ─────────────────────────

    private void ShowSetup()
    {
        var shelf = _shelf!;
        var body = new StackPanel { Spacing = 14 };
        body.Children.Add(Ui.Text(
            "Pick where the living dex should be built. The autopilot moves (or copies, if you choose) Pokémon you already own into it, " +
            "in dex order. Nothing changes until the final step.", 18, false, Ui.Dim));

        body.Children.Add(Ui.Text("Build it in:", 24, true));
        var eligible = shelf.Sources.Where(s => !s.IsExcluded).ToList();
        if (_destinationId is null || eligible.All(s => s.Id != _destinationId))
            _destinationId = eligible.FirstOrDefault(s => s.Kind == LivingDexSourceKind.Bank)?.Id ?? eligible.FirstOrDefault()?.Id;

        foreach (var source in shelf.Sources)
        {
            if (source.IsExcluded) continue;
            var current = source;
            var chosen = current.Id == _destinationId;
            var title = current.Kind == LivingDexSourceKind.Bank
                ? "The Bank (recommended: unlimited room, never touches a game)"
                : $"{current.Label} · Gen {current.Generation} · {current.Holdings.Count} Pokémon";
            var button = new Button
            {
                Content = Ui.Text((chosen ? "●  " : "○  ") + title, 20, chosen),
                HorizontalAlignment = HorizontalAlignment.Stretch,
                HorizontalContentAlignment = HorizontalAlignment.Left,
                MinHeight = 60,
                Padding = new Thickness(18, 10),
                Background = chosen ? Ui.PanelHi : Ui.Panel,
                CornerRadius = new CornerRadius(10),
            };
            button.Click += (_, _) => { _destinationId = current.Id; ShowSetup(); };
            body.Children.Add(button);
        }

        var toBank = shelf.Sources.FirstOrDefault(x => x.Id == _destinationId)?.Kind == LivingDexSourceKind.Bank;
        if (!toBank) _copy = false;
        if (toBank)
        {
            body.Children.Add(Ui.Text("What happens to the originals?", 24, true));
            var choice = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 10 };
            var move = Ui.Btn((_copy ? "○  " : "●  ") + "Move them (they leave the game)", () => { _copy = false; ShowSetup(); }, primary: !_copy);
            var copy = Ui.Btn((_copy ? "●  " : "○  ") + "Copy them (they stay in the game)", () => { _copy = true; ShowSetup(); }, primary: _copy);
            move.FontSize = copy.FontSize = 18;
            choice.Children.Add(move);
            choice.Children.Add(copy);
            body.Children.Add(new ScrollViewer { Content = choice, HorizontalScrollBarVisibility = ScrollBarVisibility.Auto, VerticalScrollBarVisibility = ScrollBarVisibility.Disabled });
            if (_copy)
                body.Children.Add(Ui.Text("Copy mode only adds to the Bank. Your game saves are not changed at all, so party Pokémon and last copies are fine to use.", 16, false, Ui.Dim));
        }

        var skipped = shelf.Sources.Where(s => s.IsExcluded).ToList();
        if (skipped.Count > 0)
        {
            body.Children.Add(Ui.Text("Left out (never touched):", 16, false, Ui.Dim));
            foreach (var source in skipped)
                body.Children.Add(Ui.Text($"• {source.Label}: {source.ExclusionReason ?? source.Exclusion.ToString()}", 15, false, Ui.Dim));
        }

        body.Children.Add(Ui.Text("Options", 24, true));
        body.Children.Add(Option("Shiny living dex (only shiny Pokémon count)", _shiny, v => _shiny = v));
        body.Children.Add(Option("One of every form, not just one per species", _forms, v => _forms = v));
        if (!_copy)
        {
            body.Children.Add(Option("Allow Pokémon from your party", _party, v => _party = v));
            body.Children.Add(Option("Allow taking the last copy of a species out of a game", _lastCopies, v => _lastCopies = v));
        }
        if (!toBank)
            body.Children.Add(Option("Allow moves into older games (converts, with warnings)", _downgrades, v => _downgrades = v));

        var make = Ui.Btn("Make the plan (changes nothing)", () => _ = MakePlanAsync(), primary: true);
        make.IsEnabled = _destinationId is not null;
        body.Children.Add(make);

        if (_destinationId is null)
            body.Children.Add(Ui.Text("No save can be used. Add a folder with saves on the home screen first.", 18, false, Ui.Warn));

        Show(Frame("Living Dex Autopilot", body));
    }

    private static CheckBox Option(string text, bool value, Action<bool> set)
    {
        var box = new CheckBox { Content = text, IsChecked = value, FontSize = 20, MinHeight = 52 };
        box.IsCheckedChanged += (_, _) => set(box.IsChecked == true);
        return box;
    }

    // ───────────────────────── step 3: the plan ─────────────────────────

    private async Task MakePlanAsync()
    {
        Show(Frame("Living Dex Autopilot", Ui.Text("Working out the plan…", 22)));
        try
        {
            var shelf = _shelf!;
            var options = new LivingDexOptions(_destinationId!, _shiny, _forms, _lastCopies, _party, _downgrades,
                _settings.BankStartBox, _copy);
            _plan = await Task.Run(() => LivingDexPlanner.Plan(shelf.Catalog, shelf.Sources, options));
            ShowPlan();
        }
        catch (Exception error)
        {
            Show(Frame("Living Dex Autopilot", Back(ShowSetup, Ui.Text("The plan failed: " + error.Message, 20, false, Ui.Warn))));
        }
    }

    private string StepText(LivingDexStep step)
    {
        var name = Svc.SpeciesName(step.Species);
        var form = step.Form > 0 && _plan!.Options.Forms ? $" ({LivingDexCatalogBuilder.FormName(step.Species, step.Form)})" : "";
        var shiny = step.Shiny ? " ★" : "";
        var from = step.SourceId is null ? "?" : SourceLabel(step.SourceId);
        var warn = step.Warnings == LivingDexWarnings.None ? "" : "  ⚠ " + step.Warnings;
        return (step.Kind switch
        {
            LivingDexStepKind.Move => $"{(_plan?.Options.CopyOnly == true ? "Copy" : "Move")} {name}{form}{shiny} from {from}{warn}",
            LivingDexStepKind.EvolveAndMove => $"Trade-evolve {Svc.SpeciesName(step.FromSpecies)} into {name}{form}{shiny} (from {from}){warn}",
            LivingDexStepKind.Arrange => $"Sort {name}{form}{shiny} into its living dex slot",
            _ => $"Still needed: {name}{form}{shiny}",
        }) + (step.Blocked is null ? "" : "  — " + step.Blocked);
    }

    private string SourceLabel(string id) =>
        _plan!.Sources.FirstOrDefault(s => s.Id == id)?.Label ?? "?";

    private void ShowPlan()
    {
        var plan = _plan!;
        var body = new StackPanel { Spacing = 12 };
        body.Children.Add(Ui.Text($"Living dex in {plan.DestinationLabel}", 26, true));
        body.Children.Add(Ui.Text(
            $"{plan.CoveredBefore} of {plan.TargetCount} slots filled now. " +
            $"You own {plan.OwnedAnywhere} of {plan.TargetCount} across everything. " +
            $"After this plan: {plan.CoveredAfter} of {plan.TargetCount}.", 20));

        var counts = new List<string>();
        if (plan.Moves > 0) counts.Add($"{plan.Moves} to {(plan.Options.CopyOnly ? "copy" : "move")}");
        if (plan.Evolutions > 0) counts.Add($"{plan.Evolutions} trade evolutions");
        if (plan.Arranges > 0) counts.Add($"{plan.Arranges} to sort");
        if (plan.Guides > 0) counts.Add($"{plan.Guides} you still need to catch");
        if (plan.BlockedCount > 0) counts.Add($"{plan.BlockedCount} blocked (no room)");
        if (plan.Downgrades > 0) counts.Add($"{plan.Downgrades} go to an older game (converted)");
        body.Children.Add(Ui.Text(counts.Count == 0 ? "Nothing to do." : string.Join(" · ", counts), 18, false, Ui.Dim));

        var touched = plan.TouchedSaves.Select(SourceLabel).ToList();
        if (touched.Count > 0)
            body.Children.Add(Ui.Text("Save files that would be written: " + string.Join(", ", touched), 18, false, Ui.Warn));
        foreach (var source in plan.Sources.Where(s => s.Caution is not null && plan.TouchedSaves.Contains(s.Id)))
            body.Children.Add(Ui.Text($"⚠ {source.Label}: {source.Caution}", 16, false, Ui.Warn));

        var runnable = plan.Steps.Where(s => s.IsRunnable).ToList();
        if (runnable.Count > 0)
        {
            body.Children.Add(Ui.Text($"What will happen ({runnable.Count})", 22, true));
            body.Children.Add(StepList(runnable));
        }

        var missing = plan.Steps.Where(s => s.Kind == LivingDexStepKind.Guide).ToList();
        if (missing.Count > 0)
        {
            body.Children.Add(Ui.Text($"Still missing from your collection ({missing.Count})", 22, true));
            body.Children.Add(StepList(missing));
        }

        var actions = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 12 };
        actions.Children.Add(Ui.Btn("‹ Change options", ShowSetup));
        if (plan.HasWork)
            actions.Children.Add(Ui.Btn("Dry run (still changes nothing)", () => _ = DryRunAsync(), primary: true));
        body.Children.Add(actions);

        Show(Frame("Living Dex Autopilot", body));
    }

    private Control StepList(IReadOnlyList<LivingDexStep> steps)
    {
        const int cap = 60;
        var list = new StackPanel { Spacing = 4 };
        foreach (var step in steps.Take(cap))
            list.Children.Add(Ui.Text("• " + StepText(step), 16));
        if (steps.Count > cap)
            list.Children.Add(Ui.Text($"…and {steps.Count - cap} more.", 16, false, Ui.Dim));
        return new Border { Background = Ui.Panel, CornerRadius = new CornerRadius(10), Padding = new Thickness(16, 12), Child = list };
    }

    // ───────────────────────── step 4: dry run ─────────────────────────

    private async Task DryRunAsync()
    {
        var plan = _plan!;
        var status = Ui.Text("Starting the dry run…", 22);
        Show(Frame("Dry run", status));
        try
        {
            _staging?.Dispose();
            _cts = new CancellationTokenSource();
            var progress = new Progress<LivingDexProgress>(p => status.Text = $"{p.Message}  ({p.Done}/{p.Total})");
            var executor = Svc.CreateLivingDexExecutor();
            _staging = await Task.Run(() => executor.StageAsync(plan, _shelf!.Saves, progress, _cts.Token));
            ShowDryRunResult();
        }
        catch (Exception error)
        {
            Show(Frame("Dry run", Back(ShowPlan, Ui.Text(
                "Stopped before anything was written: " + error.Message, 20, false, Ui.Warn))));
        }
    }

    private void ShowDryRunResult()
    {
        var staging = _staging!;
        var body = new StackPanel { Spacing = 12 };
        body.Children.Add(Ui.Text("Dry run finished. Nothing was written.", 26, true));
        body.Children.Add(Ui.Text(
            $"{staging.Staged} ready · {staging.Failed} cannot be done (those Pokémon just stay where they are)", 20));
        if (staging.IllegalResults > 0)
            body.Children.Add(Ui.Text($"⚠ {staging.IllegalResults} would end up flagged as not legal by the checker.", 18, false, Ui.Warn));

        var problems = staging.StepOutcomes.Where(o => o.Status == LivingDexStepStatus.Failed || o.Legal == false || o.Warnings.Count > 0).ToList();
        if (problems.Count > 0)
        {
            body.Children.Add(Ui.Text("Things to look at", 22, true));
            var list = new StackPanel { Spacing = 4 };
            foreach (var outcome in problems.Take(40))
                list.Children.Add(Ui.Text($"• {Svc.SpeciesName(outcome.Step.Species)}: {outcome.Message}"
                    + (outcome.Warnings.Count > 0 ? " (" + string.Join("; ", outcome.Warnings) + ")" : ""), 16));
            body.Children.Add(new Border { Background = Ui.Panel, CornerRadius = new CornerRadius(10), Padding = new Thickness(16, 12), Child = list });
        }

        var actions = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 12 };
        actions.Children.Add(Ui.Btn("‹ Back to plan", () => { _staging?.Dispose(); _staging = null; ShowPlan(); }));
        if (staging.Staged > 0)
            actions.Children.Add(Ui.Btn("Apply for real…", ShowConfirm, primary: true));
        body.Children.Add(actions);
        Show(Frame("Dry run", body));
    }

    // ───────────────────────── step 5: confirm + apply ─────────────────────────

    private void ShowConfirm()
    {
        var plan = _plan!;
        var body = new StackPanel { Spacing = 16 };
        body.Children.Add(Ui.Text("Are you sure?", 30, true));
        var touched = plan.TouchedSaves.Select(SourceLabel).ToList();
        body.Children.Add(Ui.Text(touched.Count > 0
            ? "This will change these save files: " + string.Join(", ", touched) + "."
            : "This only changes the PKForge Bank. No game save is touched.", 20));
        body.Children.Add(Ui.Text(
            "Before the first write, every save gets a restore point. If anything goes wrong while writing, " +
            "everything is put back automatically. Close your emulators first: a running emulator can overwrite the file.",
            18, false, Ui.Dim));
        var actions = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 12 };
        actions.Children.Add(Ui.Btn("Cancel", ShowDryRunResult));
        actions.Children.Add(Ui.Btn("Yes, apply it", () => _ = ApplyAsync(), primary: true));
        body.Children.Add(actions);
        Show(Frame("Confirm", body));
    }

    private async Task ApplyAsync()
    {
        var staging = _staging!;
        var status = Ui.Text("Writing…", 22);
        Show(Frame("Applying", status));
        try
        {
            _cts = new CancellationTokenSource();
            var progress = new Progress<LivingDexProgress>(p => status.Text = $"{p.Message}  ({p.Done}/{p.Total})");
            var executor = Svc.CreateLivingDexExecutor();
            var result = await Task.Run(() => executor.CommitAsync(staging, progress, CancellationToken.None));
            if (result.Committed && _plan!.DestinationKind == LivingDexSourceKind.Bank)
            {
                _settings.BankStartBox = _plan.BankStartBox;
                SettingsStore.Save(_settings);
            }
            ShowResult(result);
        }
        catch (Exception error)
        {
            Show(Frame("Applying", Back(_close, Ui.Text(
                "The run stopped: " + error.Message + "\nIf any save was written it was restored. Check your saves before playing.",
                20, false, Ui.Warn))));
        }
        finally
        {
            _staging?.Dispose();
            _staging = null;
        }
    }

    private void ShowResult(LivingDexRunResult result)
    {
        var body = new StackPanel { Spacing = 12 };
        body.Children.Add(Ui.Text(result.Committed ? "Done!" : result.RolledBack ? "Rolled back: nothing changed" : "Not applied", 30, true,
            result.Committed ? Ui.Gold : Ui.Warn));
        body.Children.Add(Ui.Text(result.Summary, 20));
        if (result.Committed)
            body.Children.Add(Ui.Text($"Living dex: {result.CoveredBefore} → {result.CoveredAfter} slots filled.", 20));
        if (result.Error is not null)
            body.Children.Add(Ui.Text(result.Error, 18, false, Ui.Warn));
        if (result.BackupIds.Count > 0)
            body.Children.Add(Ui.Text(
                $"Restore points saved for {result.BackupIds.Count} save(s) in " + AppPaths.BackupsHint + ".", 16, false, Ui.Dim));
        body.Children.Add(Ui.Btn("Done", _close, primary: true));
        Show(Frame("Living Dex Autopilot", body));
    }

    // ───────────────────────── layout helpers ─────────────────────────

    private void Show(Control content) => _host.Content = content;

    private Control Frame(string title, Control body)
    {
        var back = Ui.Btn("‹ Home", Escape);
        back.Margin = new Thickness(0, 0, 18, 0);
        DockPanel.SetDock(back, Dock.Left);
        var header = new DockPanel { Margin = new Thickness(0, 0, 0, 16) };
        header.Children.Add(back);
        header.Children.Add(Ui.Text(title, 32, true));
        DockPanel.SetDock(header, Dock.Top);

        var root = new DockPanel { Margin = new Thickness(28, 20) };
        root.Children.Add(header);
        root.Children.Add(new ScrollViewer
        {
            Content = body,
            HorizontalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Disabled,
        });
        return root;
    }

    private static Control Back(Action back, Control message)
    {
        var panel = new StackPanel { Spacing = 16 };
        panel.Children.Add(message);
        panel.Children.Add(Ui.Btn("‹ Back", back));
        return panel;
    }
}
