using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Media;
using PKForge.Domain;
using PKForge.Engine;
using PKForge.Linux.Services;

namespace PKForge.Linux;

/// <summary>
/// Box tools: sort boxes, reorder them, shiny / unshiny, restore PP, remove duplicates, empty a box.
/// The grid shows the live result of every action; nothing is written until Save, and Discard puts it all back.
/// </summary>
public sealed class BoxToolsPage : IScreen
{
    private readonly ContentControl _host;
    private readonly SpriteStore _sprites;
    private readonly Action _close;

    private Workbench? _bench;
    private int _box;
    private int _boxCount;
    private bool _allBoxes;
    private bool _reverse;
    private bool _dirty;
    private bool _busy;
    private string _note = "";
    private string? _askText;
    private Func<string>? _askAction;

    private static readonly (SortCriteria Criteria, string Label)[] SortChoices =
    [
        (SortCriteria.DexNumber, "Dex number"),
        (SortCriteria.Alphabetical, "A to Z"),
        (SortCriteria.LevelDesc, "Level"),
        (SortCriteria.IvTotalDesc, "IV total"),
        (SortCriteria.Type, "Type"),
        (SortCriteria.AgeOldest, "Oldest first"),
        (SortCriteria.ShinyFirst, "Shiny first"),
    ];

    public BoxToolsPage(ContentControl host, SpriteStore sprites, Action close)
    {
        _host = host;
        _sprites = sprites;
        _close = close;
    }

    public void Escape()
    {
        if (_busy) return;
        if (_askAction is not null) { _askAction = null; _askText = null; Render(); return; }
        if (_bench is null) { _close(); return; }
        if (_dirty)
        {
            _askText = "Throw away your unsaved box changes?";
            _askAction = () => { _ = DiscardAsync(true); return ""; };
            Render();
            return;
        }
        _bench = null;
        Start();
    }

    public IReadOnlyList<(string Button, string Label)> PadHints =>
        _bench is null ? [] : [("L1 / R1", "Box"), ("X", "Save")];

    public bool OnKey(Key key)
    {
        if (_bench is null || _busy) return false;
        if (key == Key.X && _dirty && _bench.Refusal is null) { _ = SaveAsync(); return true; }
        if (key is Key.PageUp) { MoveBox(-1); return true; }
        if (key is Key.PageDown) { MoveBox(1); return true; }
        return false;
    }

    private void MoveBox(int delta)
    {
        if (_boxCount == 0) return;
        _box = (_box + delta + _boxCount) % _boxCount;
        Render();
    }

    public void Start()
    {
        _host.Content = Workbench.Frame("Box Tools", _close,
            Workbench.SavePicker("Which save's boxes do you want to work on?", _ => true,
                "No saves found yet. Add a folder on the Folders screen first.", Open), "‹ Home");
    }

    private async void Open(DetectedSave save)
    {
        _host.Content = Workbench.Frame("Box Tools", Escape, Ui.Text("Opening the boxes…", 22));
        try
        {
            _bench = await Workbench.OpenAsync(save);
            _dirty = false;
            _box = 0;
            _allBoxes = false;
            _askAction = null;
            _askText = null;
            _note = _bench.Refusal ?? "";
            _boxCount = CountBoxes();
            if (!_bench.Session.SupportsBoxTools)
            {
                _bench = null;
                _host.Content = Workbench.Frame("Box Tools", Start,
                    Ui.Text("This game's save does not support the box tools (ROM hacks are excluded to stay safe).", 20, false, Ui.Warn));
                return;
            }
            Render();
        }
        catch (Exception error)
        {
            _bench = null;
            _host.Content = Workbench.Frame("Box Tools", Start, Ui.Text("Could not open that save: " + error.Message, 20, false, Ui.Warn));
        }
    }

    private int CountBoxes() => _bench!.Session.Snapshot.Slots.Where(s => s.Box >= 0).Select(s => s.Box + 1).DefaultIfEmpty(0).Max();

    private IReadOnlyList<(int Box, int Slot)> ScopeSlots()
    {
        var boxes = _allBoxes ? Enumerable.Range(0, _boxCount) : [_box];
        var slotsPerBox = _bench!.Session.Snapshot.Slots.Where(s => s.Box == 0).Count();
        if (slotsPerBox == 0) slotsPerBox = 30;
        return [.. boxes.SelectMany(b => Enumerable.Range(0, slotsPerBox).Select(s => (b, s)))];
    }

    // ───────────────────────── page ─────────────────────────

    private void Render()
    {
        var bench = _bench!;
        var session = bench.Session;
        var editable = bench.Refusal is null && !_busy;

        // left: the live box
        var left = new DockPanel();
        var prev = Ui.Btn("‹", () => MoveBox(-1));
        var next = Ui.Btn("›", () => MoveBox(1));
        prev.MinWidth = next.MinWidth = 70;
        prev.IsEnabled = next.IsEnabled = !_busy;
        string boxName;
        try { boxName = session.GetBoxName(_box); } catch (Exception) { boxName = "BOX"; }
        var title = Ui.Text($"Box {_box + 1} of {_boxCount}  ·  {boxName}", 20, true);
        title.HorizontalAlignment = HorizontalAlignment.Center;
        title.VerticalAlignment = VerticalAlignment.Center;
        var nav = new DockPanel { Margin = new Thickness(0, 0, 0, 8) };
        DockPanel.SetDock(prev, Dock.Left);
        DockPanel.SetDock(next, Dock.Right);
        nav.Children.Add(prev);
        nav.Children.Add(next);
        nav.Children.Add(title);
        DockPanel.SetDock(nav, Dock.Top);
        left.Children.Add(nav);

        var grid = new UniformGrid { Columns = 6 };
        var slotsInBox = Math.Max(30, session.Snapshot.Slots.Count(s => s.Box == 0));
        for (var slot = 0; slot < slotsInBox; slot++)
            grid.Children.Add(Tile(session, _box, slot));
        left.Children.Add(new ScrollViewer { Content = grid, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled });

        // right: the tools
        var tools = new StackPanel { Spacing = 8 };
        tools.Children.Add(Ui.Text("Apply to", 18, true));
        var scope = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        scope.Children.Add(Chip("This box", !_allBoxes, () => { _allBoxes = false; Render(); }));
        scope.Children.Add(Chip("All boxes", _allBoxes, () => { _allBoxes = true; Render(); }));
        tools.Children.Add(scope);

        tools.Children.Add(Ui.Text("Sort", 18, true));
        var sort = new WrapPanel();
        foreach (var (criteria, label) in SortChoices)
        {
            var c = criteria;
            var b = Chip(label, false, () => Run(() =>
            {
                var placed = session.SortBoxes(c, _allBoxes ? null : [_box], _reverse);
                return $"Sorted {placed} Pokémon by {label.ToLowerInvariant()}.";
            }));
            b.IsEnabled = editable;
            b.Margin = new Thickness(0, 0, 6, 6);
            sort.Children.Add(b);
        }
        tools.Children.Add(sort);
        var rev = Chip(_reverse ? "Reverse order: on" : "Reverse order: off", _reverse, () => { _reverse = !_reverse; Render(); });
        tools.Children.Add(rev);

        tools.Children.Add(Ui.Text("Pokémon", 18, true));
        var actions = new WrapPanel();
        Button Act(string text, Func<string> work, string? ask = null)
        {
            var b = Chip(text, false, () =>
            {
                if (ask is null) Run(work);
                else { _askText = ask; _askAction = work; Render(); }
            });
            b.IsEnabled = editable;
            b.Margin = new Thickness(0, 0, 6, 6);
            return b;
        }
        actions.Children.Add(Act("Make shiny", () => Bulk("Made shiny", s => BulkBoxActions.SetShiny(session, s, true))));
        actions.Children.Add(Act("Make not shiny", () => Bulk("Made not shiny", s => BulkBoxActions.SetShiny(session, s, false))));
        actions.Children.Add(Act("Restore PP", () => Bulk("Restored", s => BulkBoxActions.Heal(session, s))));
        actions.Children.Add(Act("Remove duplicates", () => RemoveDuplicates(session),
            "Remove duplicate Pokémon (identical clones) in the chosen boxes, keeping one of each?"));
        tools.Children.Add(actions);

        var copyBox = Chip("Copy this box as Showdown text", false, () => _ = CopyBoxAsync(session));
        copyBox.IsEnabled = !_busy;
        tools.Children.Add(copyBox);
        tools.Children.Add(Ui.Text("This box", 18, true));
        var boxActions = new WrapPanel();
        boxActions.Children.Add(Act("Move up", () => Swap(session, _box - 1)));
        boxActions.Children.Add(Act("Move down", () => Swap(session, _box + 1)));
        boxActions.Children.Add(Act("Empty this box", () =>
        {
            session.ClearBox(_box);
            return $"Box {_box + 1} emptied.";
        }, $"Empty box {_box + 1}? Every Pokémon in it is released (unless you discard before saving)."));
        tools.Children.Add(boxActions);

        if (_askAction is not null)
        {
            var yes = Ui.Btn("Yes, do it", () =>
            {
                var work = _askAction;
                _askAction = null;
                _askText = null;
                Run(work!);
            }, primary: true);
            var no = Ui.Btn("No", () => { _askAction = null; _askText = null; Render(); });
            var row = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
            row.Children.Add(yes);
            row.Children.Add(no);
            tools.Children.Add(new Border
            {
                Background = Ui.Bg,
                BorderBrush = Ui.Warn,
                BorderThickness = new Thickness(2),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(12),
                Child = new StackPanel { Spacing = 8, Children = { Ui.Text(_askText ?? "", 17, false, Ui.Warn), row } },
            });
        }

        var save = Ui.Btn("Save to the game", () => _ = SaveAsync(), primary: true);
        save.IsEnabled = _dirty && bench.Refusal is null && !_busy;
        var discard = Ui.Btn("Discard changes", () => _ = DiscardAsync(false));
        discard.IsEnabled = _dirty && !_busy;
        var finish = new WrapPanel { Margin = new Thickness(0, 6, 0, 0) };
        save.Margin = new Thickness(0, 0, 8, 6);
        finish.Children.Add(save);
        finish.Children.Add(discard);
        tools.Children.Add(finish);
        tools.Children.Add(Ui.Text(_busy ? "Working…" : _note, 15, false, Ui.Warn));

        var side = new Border
        {
            Width = 400,
            Padding = new Thickness(16),
            Margin = new Thickness(16, 0, 0, 0),
            Background = Ui.Panel,
            CornerRadius = new CornerRadius(12),
            Child = new ScrollViewer { Content = tools },
        };
        var body = new DockPanel();
        DockPanel.SetDock(side, Dock.Right);
        body.Children.Add(side);
        body.Children.Add(left);
        _host.Content = Workbench.Frame($"Box Tools · {bench.Save.GameLabel.Replace("Pokémon ", "")}", Escape, body);
    }

    private Button Chip(string text, bool on, Action click)
    {
        var b = Ui.Btn(text, click, primary: on);
        b.MinWidth = 0;
        b.MinHeight = 46;
        b.FontSize = 16;
        b.Padding = new Thickness(12, 4);
        return b;
    }

    private Control Tile(ISaveEngineSession session, int box, int slot)
    {
        Control content;
        try
        {
            var d = session.ReadEntity(box, slot);
            content = !d.IsEmpty && _sprites.GetFilled(d.Look) is { } sprite
                ? new Image { Source = sprite, Stretch = Stretch.Uniform, Margin = new Thickness(0) }
                : new Panel();
        }
        catch (Exception) { content = new Panel(); }
        return new Border
        {
            Height = 84,
            Margin = new Thickness(2),
            Background = Ui.Panel,
            CornerRadius = new CornerRadius(6),
            Child = content,
        };
    }

    // ───────────────────────── actions ─────────────────────────

    private async void Run(Func<string> work)
    {
        if (_busy) return;
        _busy = true;
        _note = "";
        Render();
        try
        {
            _note = await Task.Run(work);
            _dirty = true;
            _boxCount = CountBoxes();
            _box = Math.Clamp(_box, 0, Math.Max(0, _boxCount - 1));
        }
        catch (Exception error)
        {
            _note = "That did not work: " + error.Message;
        }
        _busy = false;
        Render();
    }

    private string Bulk(string verb, Func<IReadOnlyList<(int Box, int Slot)>, BulkOutcome> action)
    {
        var outcome = action(ScopeSlots());
        var text = $"{verb} {outcome.Changed} Pokémon.";
        if (outcome.Skipped > 0) text += $" {outcome.Skipped} left unchanged" + (outcome.Notes.Count > 0 ? $" ({outcome.Notes[0]})." : ".");
        return text;
    }

    private string RemoveDuplicates(ISaveEngineSession session)
    {
        var extras = BulkBoxActions.FindCloneExtras(session, ScopeSlots());
        foreach (var (box, slot) in extras) session.ReleaseSlot(box, slot);
        return extras.Count == 0 ? "No duplicates found." : $"Removed {extras.Count} duplicate(s).";
    }

    private string Swap(ISaveEngineSession session, int other)
    {
        if (other < 0 || other >= _boxCount) throw new InvalidOperationException("There is no box in that direction.");
        var from = _box;
        session.SwapBoxes(from, other);
        _box = other;
        return $"Box {from + 1} and box {other + 1} swapped places.";
    }

    private async Task CopyBoxAsync(ISaveEngineSession session)
    {
        try
        {
            var text = session.ExportBoxShowdown(_box);
            _note = string.IsNullOrWhiteSpace(text)
                ? "This box is empty."
                : await Workbench.CopyAsync(_host, text) ? $"Copied box {_box + 1} as Showdown text." : "The clipboard would not take it.";
        }
        catch (Exception error) { _note = "Could not make the text: " + error.Message; }
        Render();
    }

    private async Task DiscardAsync(bool leave)
    {
        if (_bench is null) return;
        try { await _bench.ReloadAsync(); } catch (Exception) { }
        _dirty = false;
        _askAction = null;
        _askText = null;
        _note = "Changes discarded.";
        if (leave) { _bench = null; Start(); return; }
        Render();
    }

    private async Task SaveAsync()
    {
        var bench = _bench;
        if (bench is null || _busy) return;
        _busy = true;
        Render();
        try
        {
            _note = await bench.CommitAsync("Reorganised boxes in PKForge");
            _dirty = false;
        }
        catch (Exception error) { _note = "Could not save: " + error.Message; }
        _busy = false;
        Render();
    }
}
