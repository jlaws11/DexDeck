using Avalonia.Media.Imaging;

namespace PKForge.Linux.Services;

/// <summary>The bundled game cover art (256x256), looked up the way the Android app does: by a slug of the game label.</summary>
public static class GameArtStore
{
    private static readonly string Root = Path.Combine(AppContext.BaseDirectory, "assets", "gameart");
    private static readonly Dictionary<string, Bitmap?> Cache = [];

    public static Bitmap? Get(string? label)
    {
        if (string.IsNullOrWhiteSpace(label)) return null;
        if (Cache.TryGetValue(label, out var cached)) return cached;
        const string prefix = "Pokémon ";
        var name = label.StartsWith(prefix, StringComparison.Ordinal) ? label[prefix.Length..] : label;
        var bitmap = Load(Slug(name));
        // A pair the save cannot split ("FireRed / LeafGreen") falls back to the first game's art.
        if (bitmap is null && name.Split(" / ") is [var first, _]) bitmap = Load(Slug(first));
        Cache[label] = bitmap;
        return bitmap;
    }

    private static string Slug(string name) =>
        string.Concat(name.ToLowerInvariant().Select(c => char.IsAscii(c) && char.IsLetterOrDigit(c) ? c : '-'));

    private static Bitmap? Load(string slug)
    {
        var path = Path.Combine(Root, slug + ".png");
        if (!File.Exists(path)) return null;
        try { return new Bitmap(path); }
        catch (Exception) { return null; }
    }
}
