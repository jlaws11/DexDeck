using PKForge.Domain;

namespace PKForge.Linux.Services;

/// <summary>Reads and writes save files as plain files. The document id is the file's full path.</summary>
public sealed class LinuxSaveFileAccess : ISaveFileAccess
{
    public ValueTask<ReadOnlyMemory<byte>> ReadAsync(string documentId, CancellationToken cancellationToken = default) =>
        new(Task.Run<ReadOnlyMemory<byte>>(() => AppPaths.ReadShared(documentId), cancellationToken));

    /// <summary>Writes a temp file beside the save, then swaps it in, so a crash never leaves half a save.</summary>
    public ValueTask WriteAtomicallyAsync(string documentId, ReadOnlyMemory<byte> bytes, CancellationToken cancellationToken = default)
    {
        var temp = documentId + ".pkforge-tmp";
        try
        {
            using (var stream = new FileStream(temp, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                stream.Write(bytes.Span);
                stream.Flush(true);
            }
            File.Move(temp, documentId, overwrite: true);
        }
        catch
        {
            try { if (File.Exists(temp)) File.Delete(temp); } catch (Exception) { /* best effort */ }
            throw;
        }
        return ValueTask.CompletedTask;
    }
}
