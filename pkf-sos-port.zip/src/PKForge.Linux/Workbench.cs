using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Layout;
using PKForge.Domain;
using PKForge.Linux.Services;

namespace PKForge.Linux;

/// <summary>
/// A whole save opened for editing things that are not one Pokémon (bag, trainer card, Pokédex).
/// Edits happen on a throwaway in-memory session; nothing touches the file until <see cref="CommitAsync"/>,
/// which checks the file did not change underneath, makes a restore point, then writes atomically.
/// </summary>
public sealed class Workbench
{
    public required DetectedSave Save { get; init; }
    public ISaveEngineSession Session { get; private set; } = null!;
    public string? Refusal { get; private set; }
    private byte[] _bytes = [];
    private SaveSnapshot _snapshot = null!;

    public static async Task<Workbench> OpenAsync(DetectedSave save)
    {
        var bench = new Workbench { Save = save };
        await bench.ReloadAsync();
        return bench;
    }

    /// <summary>Re-reads the file and starts a fresh session (also drops unsaved edits).</summary>
    public async Task ReloadAsync()
    {
        _bytes = (await Svc.Access.ReadAsync(Save.DocumentId)).ToArray();
        Session = Svc.Engine.OpenSession(_bytes, Save.EngineHint, Save.Format);
        _snapshot = Session.Snapshot;
        Refusal = Svc.Writer.WhyWritesAreRefused(Save.DocumentId, _snapshot);
    }

    /// <summary>Writes the session's changes safely; returns a message for the player.</summary>
    public async Task<string> CommitAsync(string description)
    {
        if (Refusal is not null) throw new InvalidOperationException(Refusal);
        var current = await Svc.Access.ReadAsync(Save.DocumentId);
        if (!current.Span.SequenceEqual(_bytes))
            throw new InvalidOperationException(
                "The save changed on disk since you opened it. Is the emulator running? Close it and open this screen again.");

        var candidate = Session.Serialize();
        var receipt = await Svc.Writer.WriteAsync(Save.DocumentId, _snapshot, candidate, description);
        if (receipt.Changed) Svc.Sessions.MarkWritten(Save.DocumentId, candidate);
        await ReloadAsync();
        return receipt.Changed
            ? "Saved. A restore point of the original was made first."
            : "Nothing was different, so nothing was written.";
    }

    /// <summary>Puts a restore point's bytes back as the whole save. The current state is backed up first.</summary>
    public async Task<string> RestoreAsync(byte[] bytes)
    {
        if (Refusal is not null) throw new InvalidOperationException(Refusal);
        var current = await Svc.Access.ReadAsync(Save.DocumentId);
        if (!current.Span.SequenceEqual(_bytes))
            throw new InvalidOperationException("The save changed on disk since you opened this screen. Is the emulator running? Close it and try again.");
        var receipt = await Svc.Writer.WriteScopedAsync(Save.DocumentId, _snapshot, bytes, WriteScope.Everything,
            "Safety copy: the state right before this restore");
        if (receipt.Changed) Svc.Sessions.MarkWritten(Save.DocumentId, bytes);
        await ReloadAsync();
        return receipt.Changed
            ? "Restored. The state from just before is kept as a new restore point."
            : "That restore point matches the current save, so nothing was written.";
    }

    /// <summary>Copies text to the clipboard; false if the system would not take it.</summary>
    public static async Task<bool> CopyAsync(Control from, string text)
    {
        try
        {
            if (TopLevel.GetTopLevel(from)?.Clipboard is { } clipboard)
            {
                var data = new DataTransfer();
                data.Add(DataTransferItem.CreateText(text));
                await clipboard.SetDataAsync(data);
                return true;
            }
        }
        catch (Exception) { }
        return false;
    }

    /// <summary>The list of saves to choose from; every editor screen starts with this.</summary>
    public static Control SavePicker(string prompt, Func<DetectedSave, bool> filter, string noneText, Action<DetectedSave> pick)
    {
        var list = new StackPanel { Spacing = 10 };
        list.Children.Add(Ui.Text(prompt, 18, false, Ui.Dim));
        var any = false;
        foreach (var save in Shelf.All.Where(filter))
        {
            any = true;
            var chosen = save;
            var thumb = GameArtStore.Get(save.ArtLabel ?? save.GameLabel);
            var row = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 14 };
            if (thumb is not null)
                row.Children.Add(new Avalonia.Controls.Image { Source = thumb, Width = 56, Height = 56 });
            var text = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            text.Children.Add(Ui.Text(save.GameLabel.Replace("Pokémon ", ""), 20, true));
            text.Children.Add(Ui.Text(save.TrainerName ?? "", 15, false, Ui.Dim));
            row.Children.Add(text);
            var button = new Button
            {
                Content = row,
                MinHeight = 72,
                Padding = new Thickness(14, 8),
                HorizontalAlignment = HorizontalAlignment.Stretch,
                HorizontalContentAlignment = HorizontalAlignment.Left,
                Background = Ui.Panel,
                BorderBrush = Ui.Edge,
                BorderThickness = new Thickness(2),
                CornerRadius = new CornerRadius(8),
            };
            button.Click += (_, _) => pick(chosen);
            list.Children.Add(button);
        }
        if (!any) list.Children.Add(Ui.Text(noneText, 18, false, Ui.Warn));
        return new ScrollViewer { Content = list };
    }

    /// <summary>The common page frame: a Back button and a title above the body.</summary>
    public static Control Frame(string title, Action back, Control body, string backText = "‹ Back")
    {
        var backButton = Ui.Btn(backText, back);
        backButton.Margin = new Thickness(0, 0, 18, 0);
        DockPanel.SetDock(backButton, Dock.Left);
        var header = new DockPanel { Margin = new Thickness(0, 0, 0, 12) };
        header.Children.Add(backButton);
        header.Children.Add(Ui.Text(title, 30, true));
        DockPanel.SetDock(header, Dock.Top);
        var root = new DockPanel { Margin = new Thickness(24, 18) };
        root.Children.Add(header);
        root.Children.Add(body);
        return root;
    }
}
